﻿using UnityEngine;
using System.Collections;
using FairyGUI;

public class AnimationItemCom : GButton
{

    private GTextField animationName;
    private GSlider animationSlisder;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        animationName = this.GetChild("title").asTextField;
        animationSlisder = this.GetChild("n3").asSlider;
    }



    public void setVo(string name)
    {
        animationName.text = name;
    }

    public void update()
    {
    }
}
