﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;

public class ClouthItemCom : GButton {
    private GLoader photo;
    private string _url;
    public ClothModel _vo;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        photo = this.GetChild("icon").asLoader;
    }



    public void setVo(ClothModel cloth)
    {
        _vo = cloth;
        _url = CharacterConst.ResUrl + "/icon/" + _vo.icon + ".png";
        Debug.Log("=+++++++++++++++++++++++++++++++++吴枘峰" + _url);
        if (PicManger.Instance.SetData(_url) == null)
            update();
        else
            photo.texture = PicManger.Instance.SetData(_url);
    }

    public void update()
    {
        new FairyLoadIcon().loadStart(_url, typeof(ChangeAvateMainUI), photo);
    }
}
#endif
