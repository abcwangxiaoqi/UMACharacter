﻿using UnityEngine;
using System.Collections;

public class AvatRotaContoller : MonoBehaviour {
    private float startX;
    private float upX;
    private float dianX;
    // Use this for initialization
    void Start() {
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            startX = Input.mousePosition.x;
        }
        else if (Input.GetMouseButton(0))
        {
            upX = Input.mousePosition.x;
        }
        dianX = upX - startX;
        this.gameObject.transform.eulerAngles = new Vector3(this.gameObject.transform.eulerAngles.x, -dianX, this.gameObject.transform.eulerAngles.z);
    }
}
