﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;
using System.Collections.Generic;
public class ChangeAvateMainUI : MonoBehaviour
{
    private GComponent changeMainCom;
    private GList wearList;
    private GList clothList;
    private GList animationList;
    private GList changePersonList;
    private Dictionary<string, string> wearNameList = new Dictionary<string, string>();
    private List<ClothModel> IconList = new List<ClothModel>();
    private List<string> animationNameList = new List<string>();
    private Dictionary<string, EnumUmaParamters> avatHeadDic = new Dictionary<string, EnumUmaParamters>();
    private Dictionary<string, EnumUmaParamters> avatAllDic = new Dictionary<string, EnumUmaParamters>();
    private GButton manBtn;
    private GButton womanBtn;

    private ICharacterPlayer player;
    private ICharacterPlayer manPlayer;
    private ICharacterPlayer grilPlayer;
    private CharacterData female;
    private CharacterData male;

    private GButton headBtn;
    private GButton manAllBtn;
    private GButton SkinBtn;
    private bool sexBol = true;
    private ChangeAvatCom slisderItem;
    private GameObject modl_player;

    private bool onDrag = false;
    public float speed = 6f;
    private float tempSpeed;
    private float axisX;
    private float cXY;
    private GButton backSceenBtn;
    // Use this for initialization
    IEnumerator Start()
    {
        ICharacterSystem system = new CharacterSystem();
        yield return StartCoroutine(system.Initialize());
        modl_player = Instantiate(Resources.Load("Modu_player")) as GameObject;
        //modl_player.AddComponent<AvatRotaContoller>();
        female = CharacterData.defData(EnumCharacterType.Charater_Female);
        male = CharacterData.defData(EnumCharacterType.Charater_Male);
        //player = CharacterPlayerFactory.Creat(female);
        //player.Creat();
        //player.SetLocalEulerAngles(new Vector3(0, 160, 0));
        //player.SetLocalPosition(new Vector3(-4.3f, 0, 0));
        setPerson(female);

        changeMainCom = this.GetComponent<UIPanel>().ui;
        wearList = changeMainCom.GetChild("n3").asList;
        wearList.onClickItem.Add(OnWearListItem);

        clothList = changeMainCom.GetChild("n1").asList;
        clothList.onClickItem.Add(OnclothListItem);

        animationList = changeMainCom.GetChild("n0").asList;
        animationList.onClickItem.Add(OnAnimation);

        changePersonList = changeMainCom.GetChild("n2").asList;
        changePersonList.onClickItem.Add(OnAvatChangeItem);

        manBtn = changeMainCom.GetChild("n7").asButton;
        womanBtn = changeMainCom.GetChild("n8").asButton;
        manBtn.onClick.Add(onSexBtn);
        womanBtn.onClick.Add(onSexBtn);

        backSceenBtn = changeMainCom.GetChild("n16").asButton;
        backSceenBtn.onClick.Add(OnSceenBackBtn);
        headBtn = changeMainCom.GetChild("n9").asButton;
        manAllBtn = changeMainCom.GetChild("n10").asButton;
        SkinBtn = changeMainCom.GetChild("n11").asButton;
        headBtn.onClick.Add(AvatChange);
        manAllBtn.onClick.Add(AvatChange);
        SkinBtn.onClick.Add(AvatChange);
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonTwoUI", "wearBtnItem"), typeof(WearBtnItemCom));
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonTwoUI", "clouthItme"), typeof(ClouthItemCom));
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonTwoUI", "animationBtnItem"), typeof(AnimationItemCom));
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonTwoUI", "changgeCom"), typeof(ChangeAvatCom));
        wearNameList = GetData.instant.setWearDic();
        if (wearNameList != null)
            Wear();
        IconList = ClothModel.GetData();
        WearClouth("04");
        avatHeadDic = GetData.instant.setPersonHeadDic();
        avatAllDic = GetData.instant.setPersonAllDic();
        animationNameList = GetData.instant.setAnimationList();
        if (animationNameList != null)
            Animation();
    }

    // Update is called once per frame
    void Update()
    {
        if (player != null)
        {
            //this.gameObject.transform.Rotate(new Vector3(0, axisX, 0) * Rigid(), Space.World);
            player.SetLocalEulerAngles(new Vector3(0, axisX, 0) * Rigid());
            if (!Input.GetMouseButton(0))
            {
                onDrag = false;
            }
        }
        if (FairyGUI.Stage.isTouchOnUI)
        {

        }
    }
    private void OnSceenBackBtn()
    {
        IScence sceenTwo = new ScenceEditor();
    }
    /// <summary>
    /// 服装类型
    /// </summary>
    private void Wear()
    {
        wearList.RemoveChildren();
        //for (int a = 0; a < wearNameList.Count; a++)
        //{
        //    WearBtnItemCom item = (WearBtnItemCom)wearList.AddItemFromPool();
        //    item.setVo(wearNameList[a]);
        //}
        foreach (string wearTypeName in wearNameList.Keys)
        {
            WearBtnItemCom item = (WearBtnItemCom)wearList.AddItemFromPool();
            item.setVo(wearTypeName);
        }
    }
    /// <summary>
    /// 显示服装列表
    /// </summary>
    /// <param name="nuberm"></param>
    private void WearClouth(string nuberm)
    {
        clothList.RemoveChildren();
        for (int a = 0; a < IconList.Count; a++)
        {
            ClothModel Icon = IconList[a];
            if (sexBol)
            {
                if (Icon.wearpos != nuberm || Icon.sex != "02") continue;
                ClouthItemCom item = (ClouthItemCom)clothList.AddItemFromPool();
                item.setVo(IconList[a]);
            }
            else
            {
                if (Icon.wearpos != nuberm || Icon.sex != "01") continue;
                ClouthItemCom item = (ClouthItemCom)clothList.AddItemFromPool();
                item.setVo(IconList[a]);
            }
        }
    }
    /// <summary>
    /// 显示改变人物体型的类型
    /// </summary>
    /// 
    private GSlider avataSlisder;
    private void AvatChange(EventContext context)
    {
        changePersonList.RemoveChildren();
        string name = ((GObject)(context.sender)).name;
        if (name == "n9")
        {
            foreach (string animName in avatHeadDic.Keys)
            {

                ChangeAvatCom item = (ChangeAvatCom)changePersonList.AddItemFromPool();
                item.setVo(animName, avatHeadDic[animName]);
            }
        }
        else if (name == "n10")
        {
            foreach (string animName in avatAllDic.Keys)
            {
                ChangeAvatCom item = (ChangeAvatCom)changePersonList.AddItemFromPool();
                item.setVo(animName, avatAllDic[animName]);
            }
        }
    }
    /// <summary>
    /// 人物的动画
    /// </summary>
    private void Animation()
    {
        animationList.RemoveChildren();
        for (int a = 0; a < animationNameList.Count; a++)
        {
            AnimationItemCom item = (AnimationItemCom)animationList.AddItemFromPool();
            item.setVo(animationNameList[a]);
        }
    }
    /// <summary>
    /// 控制加载人物的性别
    /// </summary>
    /// <param name="context"></param>
    private void onSexBtn(EventContext context)
    {
        string name = ((GObject)(context.sender)).name;
        if (name == "n7")
        {
            setPerson(male);
            sexBol = false;
            WearClouth("04");
        }
        else
        {
            setPerson(female);
            sexBol = true;
            WearClouth("04");
        }

    }
    /// <summary>
    /// 加载人物
    /// </summary>
    /// <param name="data"></param>
    private void setPerson(CharacterData data)
    {
        if (player == null)
        {
            player = CharacterPlayerFactory.Creat(data);
            player.Creat();
            player.SetParent(modl_player.transform);
            player.SetLocalEulerAngles(new Vector3(0, 160f, 0));
            // player.SetLocalPosition(new Vector3(-4.3f, 0, 0));
        }
        else
        {
            player.Destroy();
            player = CharacterPlayerFactory.Creat(data);
            player.Creat();
            player.SetParent(modl_player.transform);
            player.SetLocalEulerAngles(new Vector3(0, 160, 0));
            //player.SetLocalPosition(new Vector3(-4.3f, 0, 0));
        }
    }
    /// <summary>
    /// 服装的类型列表点击事件
    /// </summary>
    /// <param name="context"></param>
    private void OnWearListItem(EventContext context)
    {
        GButton item = (GButton)context.data;
        GTextField textItem = item.GetChild("title").asTextField;
        Debug.Log(textItem.text);
        showClouth(textItem.text);
    }/// <summary>
    /// 点击服装类型所显示对应服装的控制
    /// </summary>
    /// <param name="name"></param>
    private void showClouth(string name)
    {
        switch (name)
        {
            case EWearNames.topClouth:
                WearClouth("04");
                break;
            case EWearNames.downClouth:
                WearClouth("05");
                break;
            case EWearNames.Clouth:
                WearClouth("30");
                break;
            case EWearNames.shoes:
                WearClouth("06");
                break;
            case EWearNames.hair:
                WearClouth("02");
                break;
        }

    }
    /// <summary>
    /// 服装列表的点击换装
    /// </summary>
    /// <param name="context"></param>
    private void OnclothListItem(EventContext context)
    {
        ClouthItemCom item = (ClouthItemCom)context.data;
        player.PutOn(item._vo);
    }
    /// <summary>
    /// 动画列表的点击
    /// </summary>
    /// <param name="context"></param>
    private void OnAnimation(EventContext context)
    {
        GButton item = (GButton)context.data;
        GTextField animationName = item.GetChild("title").asTextField;
        player.PlayAnimation(animationName.text);
    }
    private void OnAvatChangeItem(EventContext context)
    {
        Debug.Log("WURUIFENG");
        ChangeAvatCom slisderAvat = (ChangeAvatCom)context.data;
        slisderItem = slisderAvat;
        slisderAvat.SlisderName.onChanged.Add(OnSlisderItem);
    }
    public void SetChangeAvate(EnumUmaParamters paramter, float value)
    {
        Debug.Log(value + "asdadsasdas");
        player.SetDNA(paramter, value);
        Debug.Log("wuwuwuwuu");
    }
    private void OnSlisderItem()
    {
        slisderItem.SlisderName.max = 50;
        float a = (slisderItem.SlisderName.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.eyeSize, a);
        //new ChangeAvateMainUI().SetChangeAvate(slisderItem.paramter, a);
        SetChangeAvate(slisderItem.paramter, a);
    }
    void OnMouseDown()
    {
        axisX = 0f;
    }
    void OnMouseDrag()
    {
        if (!FairyGUI.Stage.isTouchOnUI)
        {
            onDrag = true;
            axisX = -Input.GetAxis("Mouse X");
            cXY = Mathf.Sqrt(axisX * axisX);
            if (cXY == 0f)
            {
                cXY = 1f;
            }
        }
    }
    private float Rigid()
    {
        if (onDrag)
        {
            tempSpeed = speed;
        }
        else
        {
            if (tempSpeed > 0)
            {
                tempSpeed -= speed * 2 * Time.deltaTime / cXY;
            }
            else
            {
                tempSpeed = 0;
            }
        }
        return tempSpeed;
    }
}
#endif