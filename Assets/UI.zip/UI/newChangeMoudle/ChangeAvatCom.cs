﻿using UnityEngine;
using System.Collections;
using FairyGUI;

public class ChangeAvatCom : GLabel {

    private GTextField avatName;
    public GSlider SlisderName;
    public EnumUmaParamters paramter;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        avatName = this.GetChild("title").asTextField;
        SlisderName = this.GetChild("n3").asSlider;
    }



    public void setVo(string name, EnumUmaParamters paramterName)
    {
        avatName.text = name;
        paramter = paramterName;
    }

    public void update()
    {
    }
}
