﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Xml;

public class GetData : MonoBehaviour {

    private Dictionary<string, string> wearDic = new Dictionary<string, string>();
    //private List<string> animationList = new List<string>();
    private string weaeName;
    private string id;
    private Dictionary<string, EnumUmaParamters> dnaHeadDic = new Dictionary<string, EnumUmaParamters>();
    private Dictionary<string, EnumUmaParamters> dnaTrunkDic = new Dictionary<string, EnumUmaParamters>();
    private static GetData inst;
    public static GetData instant
    {
        get
        {
            if (inst == null)
                inst = new GetData();
            return inst;
        }
    }
    // Use this for initialization
    private List<string> wearNameList = new List<string>();
    private List<string> animationList = new List<string>();
    private Dictionary<string, EnumUmaParamters> personHeadDic = new Dictionary<string, EnumUmaParamters>();
    private Dictionary<string, EnumUmaParamters> personAllDic = new Dictionary<string, EnumUmaParamters>();
    void Update () {
	
	}
    public Dictionary<string, string> setWearDic()
    {
        string fail = Application.dataPath + "/UI/AvatFail.xml";
        XmlDocument failDoc = new XmlDocument();
        failDoc.Load(fail);
        XmlNodeList xmlNodeList = failDoc.SelectSingleNode("root").ChildNodes;
        foreach (XmlElement xmlOneE in xmlNodeList)
        {
            if (xmlOneE.Name == "wearType")
            {
                foreach (XmlElement xmlTwoE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlTwoE.GetAttribute("name");
                    id = xmlTwoE.GetAttribute("id");
                    wearDic.Add(weaeName, id);
                    Debug.Log(wearDic.Count);
                }
            }
        }
        return wearDic;
    }
    public Dictionary<string, EnumUmaParamters> setPersonHeadDic()
    {
        personHeadDic.Add("头部大小", EnumUmaParamters.headSize);
        personHeadDic.Add("头部宽窄", EnumUmaParamters.headWidth);
        personHeadDic.Add("颈部", EnumUmaParamters.neckThickness);
        personHeadDic.Add("耳朵大小", EnumUmaParamters.earsSize);

        personHeadDic.Add("耳朵位置", EnumUmaParamters.earsPosition);
        personHeadDic.Add("耳朵旋转", EnumUmaParamters.earsRotation);
        personHeadDic.Add("鼻子大小", EnumUmaParamters.noseSize);
        personHeadDic.Add("鼻子曲线", EnumUmaParamters.noseCurve);
        personHeadDic.Add("鼻子宽度", EnumUmaParamters.noseWidth);
        personHeadDic.Add("鼻子", EnumUmaParamters.noseInclination);
        personHeadDic.Add("鼻子位置", EnumUmaParamters.nosePosition);
        personHeadDic.Add("鼻子肌肉", EnumUmaParamters.nosePronounced);
        personHeadDic.Add("鼻子高低", EnumUmaParamters.noseFlatten);
        personHeadDic.Add("下巴尖大小", EnumUmaParamters.chinSize);

        personHeadDic.Add("下巴", EnumUmaParamters.chinPronounced);
        personHeadDic.Add("下巴尖位置", EnumUmaParamters.chinPosition);
        personHeadDic.Add("下颌骨大小", EnumUmaParamters.mandibleSize);
        personHeadDic.Add("下巴大小", EnumUmaParamters.jawsSize);
        personHeadDic.Add("下巴位置", EnumUmaParamters.jawsPosition);
        personHeadDic.Add("面颊大小", EnumUmaParamters.cheekSize);
        personHeadDic.Add("面颊位置", EnumUmaParamters.cheekPosition);
        personHeadDic.Add("下面颊肌肉", EnumUmaParamters.lowCheekPronounced);
        personHeadDic.Add("下面颊位置", EnumUmaParamters.lowCheekPosition);
        personHeadDic.Add("前额大小", EnumUmaParamters.foreheadSize);

        personHeadDic.Add("前额位置", EnumUmaParamters.foreheadPosition);
        personHeadDic.Add("嘴唇大小", EnumUmaParamters.lipsSize);
        personHeadDic.Add("嘴巴大小", EnumUmaParamters.mouthSize);
        personHeadDic.Add("眼睛旋转", EnumUmaParamters.eyeRotation);
        personHeadDic.Add("眼睛大小", EnumUmaParamters.eyeSize);
        return personHeadDic;
    }
    public Dictionary<string, EnumUmaParamters> setPersonAllDic()
    {
        personAllDic.Add("身高", EnumUmaParamters.height);
        personAllDic.Add("胳膊长短", EnumUmaParamters.armLength);
        personAllDic.Add("小臂长短", EnumUmaParamters.forearmLength);
        personAllDic.Add("大臂", EnumUmaParamters.armWidth);
        personAllDic.Add("小臂", EnumUmaParamters.forearmWidth);
        personAllDic.Add("手", EnumUmaParamters.handsSize);
        personAllDic.Add("脚", EnumUmaParamters.feetSize);

        personAllDic.Add("腿部间距", EnumUmaParamters.legSeparation);
        personAllDic.Add("肩部", EnumUmaParamters.upperMuscle);
        personAllDic.Add("下身肌肉", EnumUmaParamters.lowerMuscle);
        personAllDic.Add("腰围", EnumUmaParamters.upperWeight);
        personAllDic.Add("下身宽度", EnumUmaParamters.lowerWeight);
        personAllDic.Add("腿大小", EnumUmaParamters.legsSize);
        personAllDic.Add("腹部", EnumUmaParamters.belly);
        personAllDic.Add("腰部", EnumUmaParamters.waist);
        personAllDic.Add("臀围", EnumUmaParamters.gluteusSize);
        personAllDic.Add("胸围", EnumUmaParamters.breastSize);
        return personAllDic;
    }
    public List<string> setAnimationList()
    {
        animationList.Add(ActionConst.IDLE);
        animationList.Add(ActionConst.WALK);
        animationList.Add(ActionConst.HELLO);
        animationList.Add(ActionConst.CHANGE_CLOTH);
        animationList.Add(ActionConst.DRESS_IDLE);
        animationList.Add(ActionConst.TALK);
        return animationList;
    }
}
