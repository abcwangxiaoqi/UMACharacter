﻿using UnityEngine;
using System.Xml;
using System.Collections.Generic;
public class GetXmlData : MonoBehaviour
{
    public Dictionary<string, string> wearDic = new Dictionary<string, string>();
    public List<string> animationList = new List<string>();
    private string weaeName;
    private string id;
    public Dictionary<string,EnumUmaParamters> dnaHeadDic = new Dictionary<string, EnumUmaParamters>();
    public Dictionary<string, EnumUmaParamters> dnaTrunkDic = new Dictionary<string, EnumUmaParamters>();
    // Use this for initialization
    void Start()
    {
    }
    public GetXmlData()
    {
        string fail = Application.dataPath + "/UI/AvatFail.xml";
        XmlDocument failDoc = new XmlDocument();
        failDoc.Load(fail);
        XmlNodeList xmlNodeList = failDoc.SelectSingleNode("root").ChildNodes;
        foreach (XmlElement xmlOneE in xmlNodeList)
        {
            if (xmlOneE.Name == "wearType")
            {
                foreach (XmlElement xmlTwoE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlTwoE.GetAttribute("name");
                    id = xmlTwoE.GetAttribute("id");
                    wearDic.Add(weaeName, id);
                    Debug.Log(wearDic.Count);
                }
            }
            else if (xmlOneE.Name == "animation")
            {
                foreach (XmlElement xmlThreeE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlThreeE.GetAttribute("name");
                    animationList.Add(weaeName);
                    Debug.Log(animationList.Count);
                }
            }
            else if (xmlOneE.Name == "DNAHead")
            {
                foreach (XmlElement xmlfourE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlfourE.GetAttribute("type");
                    id = xmlfourE.GetAttribute("name");
                    Debug.Log(weaeName + "------askjdklajdk");
                    EnumUmaParamters.Parse(typeof(EnumUmaParamters), weaeName);
                    dnaHeadDic.Add(id, (EnumUmaParamters)EnumUmaParamters.Parse(typeof(EnumUmaParamters), weaeName));
                }
            }
            else if (xmlOneE.Name == "DNATrunk")
            {
                foreach (XmlElement xmlFiveE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlFiveE.GetAttribute("type");
                    id = xmlFiveE.GetAttribute("name");
                    Debug.Log(weaeName + "------askjdklajdk");
                    dnaTrunkDic.Add(id, (EnumUmaParamters)EnumUmaParamters.Parse(typeof(EnumUmaParamters), weaeName));
                }
            }
        }
    }
    // Update is called once per frame
    void Update()
    {

    }
    private void getData()
    {
        string fail = Application.dataPath + "/UI/AvatFail.xml";
        XmlDocument failDoc = new XmlDocument();
        failDoc.Load(fail);
        XmlNodeList xmlNodeList = failDoc.SelectSingleNode("root").ChildNodes;
        foreach (XmlElement xmlOneE in xmlNodeList)
        {
            if (xmlOneE.Name == "wearType")
            {
                foreach (XmlElement xmlTwoE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlTwoE.GetAttribute("name");
                    id = xmlTwoE.GetAttribute("id");
                    wearDic.Add(weaeName, id);
                    Debug.Log(wearDic.Count);
                }
            }
            else if (xmlOneE.Name == "animation")
            {
                foreach (XmlElement xmlThreeE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlThreeE.GetAttribute("name");
                    animationList.Add(weaeName);
                    Debug.Log(animationList.Count);
                }
            }
            else if (xmlOneE.Name == "DNAHead")
            {
                foreach (XmlElement xmlfourE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlfourE.GetAttribute("type");
                    id = xmlfourE.GetAttribute("name");
                    Debug.Log(weaeName + "------askjdklajdk");
                    EnumUmaParamters.Parse(typeof(EnumUmaParamters), weaeName);
                    dnaHeadDic.Add(id, (EnumUmaParamters)EnumUmaParamters.Parse(typeof(EnumUmaParamters), weaeName));
                }
            }
            else if (xmlOneE.Name == "DNATrunk")
            {
                foreach (XmlElement xmlFiveE in xmlOneE.ChildNodes)
                {
                    weaeName = xmlFiveE.GetAttribute("type");
                    id = xmlFiveE.GetAttribute("name");
                    Debug.Log(weaeName + "------askjdklajdk");
                    dnaTrunkDic.Add(id, (EnumUmaParamters)EnumUmaParamters.Parse(typeof(EnumUmaParamters), weaeName));
                }
            }
        }
    }
}
