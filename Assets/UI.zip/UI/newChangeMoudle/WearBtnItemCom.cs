﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;
using System.Collections.Generic;

public class WearBtnItemCom : GButton {

    TemplateClothItem _current;
    public TemplateClothItem current
    {
        get
        {
            return _current;
        }
        set
        {
            _current = value;
            wearName.text = _current.name;
        }
    }
    public GTextField wearName;
    public GTextField dressName;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        wearName = this.GetChild("title").asTextField;
    }
    public void setVo(string name)
    {
        wearName.text = name;
    }

    public void update()
    {
    }
}
public class EWearNames
{
    public const string topClouth = "上装";
    public const string downClouth = "下装";
    public const string Clouth = "套装";
    public const string shoes = "鞋子";
    public const string hair = "头发";
    public const string glass = "眼镜";
    public const string mouth = "嘴巴";
    public const string eye = "眼睛";
    public const string jewelry = "手环";
    public const string head = "头饰";
    public const string foot = "脚饰";
    public const string Necklace = "项链";
    public const string Earrings = "耳环";
    public const string hands = "手饰";
    public const string ring = "戒指";
    public const string Backpack = "包";
    public const string FlatBottomSock = "袜子";
}
#endif
