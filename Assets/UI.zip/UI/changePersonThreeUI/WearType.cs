﻿using UnityEngine;
using System.Collections;
using FairyGUI;

public class WearType : GButton {

    public GTextField wearName;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        wearName = this.GetChild("title").asTextField;
    }
    public void setVo(string name)
    {
        wearName.text = name;
    }
}
