﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;

public class WearBtnCom : GButton
{
    private GLoader photo;
    private string _url;
    public ClothModel _vo;
    private GTextField wearId;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        photo = this.GetChild("icon").asLoader;
        wearId = this.GetChild("title").asTextField;
    }



    public void setVo(ClothModel cloth)
    {
        _vo = cloth;
        wearId.text = cloth.itemid;
        _url = CharacterConst.ResUrl + "/icon/" + _vo.icon + ".png";
        Debug.Log("=+++++++++++++++++++++++++++++++++吴枘峰" + _url);
        if (PicManger.Instance.SetData(_url) == null)
            update();
        else
            photo.texture = PicManger.Instance.SetData(_url);
    }

    public void update()
    {
        new FairyLoadIcon().loadStart(_url, typeof(ChangeAvateMainUI), photo);
    }
}
#endif
