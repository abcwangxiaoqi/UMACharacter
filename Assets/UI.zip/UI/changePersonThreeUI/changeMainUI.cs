﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;
using System.Collections.Generic;

public class changeMainUI : MonoBehaviour {
    private ICharacterPlayer player;
    private CharacterData female;
    private CharacterData male;
    private GameObject modl_player;

    private GComponent mianCom;
    private GButton sexBtn;
    private bool sexBool = true;
    private Dictionary<string, string> wearDic = new Dictionary<string, string>();
    private List<string> anmiationList = new List<string>();
    private GList wearList;
    private GComboBox wearTypeBox;
    private GList animationNameList;
    private GList dressBtnList;
    private GButton headBtn;
    private GButton manAllBtn;
    private GButton SkinBtn;
    private List<ClothModel> waerModule = new List<ClothModel>();
    private Dictionary<string, EnumUmaParamters> avatHeadDic = new Dictionary<string, EnumUmaParamters>();
    private Dictionary<string, EnumUmaParamters> avatAllDic = new Dictionary<string, EnumUmaParamters>();
    private GList avatChangeList;
    private Vector3 initPos = new Vector3();
    // Use this for initialization
    IEnumerator Start()
    {
        ICharacterSystem system = new CharacterSystem();
        yield return StartCoroutine(system.Initialize());
        modl_player = Instantiate(Resources.Load("Modu_player")) as GameObject;
        female = CharacterData.defData(EnumCharacterType.Charater_Female);
        male = CharacterData.defData(EnumCharacterType.Charater_Male);
        setPerson(female);
        initPos = modl_player.transform.position;
        mianCom = this.GetComponent<UIPanel>().ui;
        sexBtn = mianCom.GetChild("n3").asButton;
        sexBtn.onClick.Add(OnSexBtn);
        GButton backBtn = mianCom.GetChild("n2").asButton;
        backBtn.onClick.Add(() => { IScence sceenOne = new ScenceEditor(); sceenOne.Load(); });
        wearList = mianCom.GetChild("n8").asComboBox.dropdown.GetChild("list").asList;
        wearTypeBox = mianCom.GetChild("n8").asComboBox;
        //Debug.LogError(wearList.name);
        wearList.onClickItem.Add(OnWearListItem);

        animationNameList = mianCom.GetChild("n4").asList;
        animationNameList.onClickItem.Add(OnAnimationNameListItem);
        dressBtnList = mianCom.GetChild("n9").asList;
        dressBtnList.onClickItem.Add(OnDressBtnListItem);

        headBtn = mianCom.GetChild("n15").asButton;
        manAllBtn = mianCom.GetChild("n16").asButton;
        SkinBtn = mianCom.GetChild("n17").asButton;
        headBtn.onClick.Add(AvatChange);
        manAllBtn.onClick.Add(AvatChange);
        SkinBtn.onClick.Add(AvatChange);
        avatChangeList = mianCom.GetChild("n12").asList;
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonThreeUI", "downBtn"), typeof(WearType));//穿着类型
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonThreeUI", "itemBtn"), typeof(WearBtnCom));//穿着类型的Item
        //UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonThreeUI", "animtionItem"), typeof(animationCom));//动画控制
        //UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("ChangePersonThreeUI", "itemSlisder"), typeof(ChangePersonCom));//改变人物体型

        //wearDic = GetData.instant.setWearDic();
        wearDic = new GetXmlData().wearDic;
        if (wearDic != null && player != null)
            wear();
        anmiationList = new GetXmlData().animationList;
        if (anmiationList != null && player != null)
            animationCort();
        waerModule = ClothModel.GetData();
        avatHeadDic = new GetXmlData().dnaHeadDic;
        avatAllDic = new GetXmlData().dnaTrunkDic;
        GButton upBtn = mianCom.GetChild("n20").asButton;
        upBtn.onTouchBegin.Add(changePos);
        GButton downBtn = mianCom.GetChild("n19").asButton;
        downBtn.onClick.Add(changePos);
        GButton liftBtn = mianCom.GetChild("n21").asButton;
        liftBtn.onClick.Add(changePos);
        GButton rightBtn = mianCom.GetChild("n23").asButton;
        rightBtn.onClick.Add(changePos);
        GButton zhongBtn = mianCom.GetChild("n24").asButton;
        zhongBtn.onClick.Add(changePos);
        GButton shortBtn = mianCom.GetChild("n26").asButton;
        shortBtn.onClick.Add(changePos);
        GButton bigBtn = mianCom.GetChild("n25").asButton;
        bigBtn.onClick.Add(changePos);
        WearClouth("04");
    }
	
	// Update is called once per frame
	void Update () {
	
	}
    private void OnWearListItem(EventContext context)
    {
        Debug.Log("wiekjsldfl");
        GButton itemBtn = (GButton)context.data;
        if (wearDic.ContainsKey(itemBtn.title))
        {
            WearClouth(wearDic[itemBtn.title]);
        }
    }
    private void OnSexBtn(EventContext context)
    {
        if (sexBtn.selected)
        {
            sexBool = false;
            setPerson(male);
        }
        else
        {
            sexBool = true;
            setPerson(female);
        }
    }
    private void setPerson(CharacterData data)
    {
        if (player == null)
        {
            player = CharacterPlayerFactory.Creat(data);
            player.Creat();
            player.SetParent(modl_player.transform);
        }
        else
        {
            player.Destroy();
            player = CharacterPlayerFactory.Creat(data);
            player.Creat();
            player.SetParent(modl_player.transform);
        }
    }
    private void wear()
    {
        List<string> waerName = new List<string>();
        foreach (string wearTypeName in wearDic.Keys)
        {
            waerName.Add(wearTypeName);
            wearTypeBox.items = waerName.ToArray();
        }
    }
    private void animationCort()
    {
        animationNameList.RemoveChildrenToPool();
        for (int a = 0;a < anmiationList.Count;a++)
        {
            GButton item = animationNameList.AddItemFromPool().asButton;
            item.title = anmiationList[a];
        }
    }
    private void OnAnimationNameListItem(EventContext context)
    {
        GButton item = (GButton)context.data;
        GTextField animationName = item.GetChild("title").asTextField;
        player.PlayAnimation(animationName.text);
        Debug.Log("播放成功");
        Debug.Log(item.title);
    }
    private void WearClouth(string nuberm)
    {
        dressBtnList.RemoveChildren();
        for (int a = 0; a < waerModule.Count; a++)
        {
            ClothModel Icon = waerModule[a];
            if (sexBool)
            {
                if (Icon.wearpos != nuberm || Icon.sex != "02") continue;
                WearBtnCom item = (WearBtnCom)dressBtnList.AddItemFromPool();
                item.setVo(waerModule[a]);
            }
            else
            {
                if (Icon.wearpos != nuberm || Icon.sex != "01") continue;
                WearBtnCom item = (WearBtnCom)dressBtnList.AddItemFromPool();
                item.setVo(waerModule[a]);
            }
        }
    }
    private void OnDressBtnListItem(EventContext context)
    {
        WearBtnCom item = (WearBtnCom)context.data;
        player.PutOn(item._vo);
    }
    private void AvatChange(EventContext context)
    {
        avatChangeList.RemoveChildrenToPool();
        string name = ((GObject)(context.sender)).name;
        if (name == "n15")
        {
            foreach (string animName in avatHeadDic.Keys)
            {

                GLabel item = avatChangeList.AddItemFromPool().asLabel;
                item.title = animName;
                GSlider changeAvatSlisder = item.GetChild("n0").asSlider;
                changeAvatSlisder.onChanged.Add(OnSlisderItem);
            }
        }
        else if (name == "n16")
        {
            foreach (string animName in avatAllDic.Keys)
            {
                GLabel item = avatChangeList.AddItemFromPool().asLabel;
                item.title = animName;
                GSlider changeAvatSlisder = item.GetChild("n0").asSlider;
                changeAvatSlisder.onChanged.Add(OnSlisderItemAll);
            }
        }
    }
    private void OnSlisderItem(EventContext context)
    {
        GSlider itemSlisder = ((GObject)context.sender) as GSlider;
        string nameCom = itemSlisder.parent.asLabel.GetChild("title").asTextField.text;
        if (avatHeadDic.ContainsKey(nameCom))
        {
            itemSlisder.max = 50;
            float a = (itemSlisder.value + 50) * 0.01F;
            player.SetDNA(avatHeadDic[nameCom], a);
        }
        Debug.Log("改变了 +" + nameCom);
    }
    private void OnSlisderItemAll(EventContext context)
    {
        GSlider itemSlisder = ((GObject)context.sender) as GSlider;
        string nameCom = itemSlisder.parent.asLabel.GetChild("title").asTextField.text;
        if (avatAllDic.ContainsKey(nameCom))
        {
            itemSlisder.max = 50;
            float a = (itemSlisder.value + 50) * 0.01F;
            player.SetDNA(avatAllDic[nameCom], a);
        }
        Debug.Log("改变了 +" + nameCom);
    }
    private void changePos(EventContext context)
    {
        GButton changeBtn = (GObject)context.sender as GButton;
        Debug.Log(changeBtn.name);
        if (changeBtn.name == "n20")
        {
            modl_player.transform.localPosition += new Vector3(0, 0.05f, 0);
        }
        else if (changeBtn.name == "n19")
            modl_player.transform.localPosition -= new Vector3(0, 0.2f, 0);
        else if (changeBtn.name == "n21")
            modl_player.transform.localPosition -= new Vector3(0.2f, 0, 0);
        else if (changeBtn.name == "n23")
            modl_player.transform.localPosition += new Vector3(0.2f, 0, 0);
        else if (changeBtn.name == "n24")
            modl_player.transform.localPosition = initPos;
        else if (changeBtn.name == "n26" && modl_player.transform.localScale.x > 1)
            modl_player.transform.localScale -= new Vector3(1f, 1f, 1f);
        else if (changeBtn.name == "n25")
            modl_player.transform.localScale += new Vector3(1f, 1f, 1f);
    }
}
#endif