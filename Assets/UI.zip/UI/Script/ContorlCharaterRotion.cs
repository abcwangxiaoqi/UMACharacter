﻿using UnityEngine;
using System.Collections;

public class ContorlCharaterRotion : MonoBehaviour {

    public float roate_Speed = 100.0f;//旋转速度  
    void Start () {
	
	}

    // Update is called once per frame
    void Update()
    {
        Transform target_transform = null;//不用绑定对象，下面代码动态获取对象  
        if (Input.GetMouseButton(0))
        {

            //在屏幕上转换坐标：将鼠标点转换成射线  
            Ray rayObj = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hitObj;
            if (Physics.Raycast(rayObj, out hitObj))
            {
                //Debug.Log("射线得到的对象名称：" + hitObj.collider.name);  
                target_transform = hitObj.transform;
            }


            if (target_transform != null)
            {
                //Debug.Log("射线取得对象");  
                float mousX = Input.GetAxis("Mouse X") * roate_Speed;//得到鼠标移动距离  
                target_transform.transform.Rotate(new Vector3(0, -mousX, 0));
            }
            else
            {
                Debug.Log("无法取得对象");
            }
        }

    }
}
