﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FairyGUI;

public class PicManger : MonoBehaviour
{
    static PicManger instance;
    public static PicManger Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new PicManger();
            }
            return instance;
        }
    }
    public Dictionary<string, NTexture> allTexture = new Dictionary<string, NTexture>();
    private NTexture texture;
    public GameObject obj;
    public string _url;
    // Use this for initialization
    public void SaveData(string url, NTexture texture)
    {
        allTexture.Add(url, texture);
        Debug.Log(allTexture.Keys + "________________wuruifeng++++++++++++++");
    }
    public NTexture SetData(string url)
    {
        if (allTexture.ContainsKey(url))
        {
            texture = allTexture[url];
            return texture;
        }
        else
        {
            return null;
        }
    }
    public void creatPerson()
    {
        //CharacterController.Instance.CreatCurrentUser(obj, LoadRoleComplete);
    }
    void LoadRoleComplete(GameObject go)
    {
        GameObject.Destroy(go);
    }
}

