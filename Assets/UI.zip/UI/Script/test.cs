﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {

	// Use this for initialization
	void Start () {

       ICharacterPlayer player= CharacterPlayerFactory.Creat(null);
        player.Creat();


    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
