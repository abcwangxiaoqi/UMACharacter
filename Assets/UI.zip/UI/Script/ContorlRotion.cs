﻿using UnityEngine;
using System.Collections;

public class ContorlRotion : MonoBehaviour
{
    private bool onDrag = false; 
    public float speed = 6f;
    private float tempSpeed;
    private float axisX;
    private float cXY;
    void OnMouseDown()
    {
        axisX = 0f;
    }
    void OnMouseDrag()
    {
        onDrag = true;
        axisX = -Input.GetAxis("Mouse X");
        cXY = Mathf.Sqrt(axisX * axisX);
        if (cXY == 0f)
        {
            cXY = 1f;
        }
    }
    private float Rigid()
    {
        if (onDrag)
        {
            tempSpeed = speed;
        }
        else
        {
            if (tempSpeed > 0)
            {
                tempSpeed -= speed * 2 * Time.deltaTime / cXY; 
            }
            else
            {
                tempSpeed = 0;
            }
        }
        return tempSpeed;
    }
    void Update()
    {
        this.gameObject.transform.Rotate(new Vector3(0, axisX, 0) * Rigid(), Space.World);
        if (!Input.GetMouseButton(0))
        {
            onDrag = false;
        }
    }
}
