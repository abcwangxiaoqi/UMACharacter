﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using LitJson;
using System.IO;
using FairyGUI;
using System;

public class CharaterItem :GButton{

    public ClothModel _vo;
    private GLoader photo;
    private string _url;

    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        //nameText = this.GetChild("nameText").asTextField;
        photo = this.GetChild("icon").asLoader;
        //  this.onClick.Add(onCollect);
    }



    public void setVo(ClothModel Icon)
    {
        //_vo = vo;
        _vo = Icon;
        _url = CharacterConst.ResUrl + "/icon/" + _vo.icon + ".png";
        Debug.Log("=+++++++++++++++++++++++++++++++++吴枘峰" + _url);
        if (PicManger.Instance.SetData(_url) == null)
            update();
        else
            photo.texture = PicManger.Instance.SetData(_url);
    }

    public void update()
    {
        new FairyLoadIcon().loadStart(_url, typeof(ChangePersonMainUI), photo);
    }
  
}
