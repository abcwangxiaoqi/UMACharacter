﻿using UnityEngine;
using System.Collections.Generic;
using LitJson;
using System;
using FairyGUI;
using DG.Tweening;

public class ChangePersonMainUI : MonoBehaviour {
    private GComponent mianCom;
    private GButton headBtn;
    private Controller mainCont;
    private GButton ShapeBtn;
    private GButton hairBtn;
    private GButton clothBtn;
    private GButton closeBtn;
    private GComponent showCom;
    private Controller showCont;
    private Controller slideCont;
    private GList headList;
    private GList ShapeList;
    private GList hairList;
    private GList clothList;
    private GButton manBtn;
    private GButton grilBtn;
    private CharacterData female;
    private CharacterData male;

    private GList ItemList;
    private ICharacterPlayer player;
    private ICharacterPlayer manPlayer;
    private ICharacterPlayer grilPlayer;

    private string index;
    private List<ClothModel> clouthItm = new List<ClothModel>();
    private int six = 1;
    private GList animationList;
    public GameObject parent;
    #region 全部滑动条字段
    //眼睛 头部
    private GSlider eyesBigSlisder;
    private GSlider wocanSlisder;
    private GSlider headBigSlisder;
    private GSlider headSlisder;
    //鼻子
    private GSlider noseOneSlisder;
    private GSlider noseTwoSlisder;
    private GSlider noseThreeSlisder;
    private GSlider noseFourSlisder;
    private GSlider noseFiveSlisder;
    private GSlider noseSixSlisder;
    private GSlider noseSvenSlisder;
    //下巴
    private GSlider xiaBaOneSlisder;
    private GSlider xiaBaTwoSlisder;
    private GSlider xiaBaThreeSlisder;
    private GSlider xiaBaFourSlisder;
    private GSlider xiaBaFiveSlisder;
    private GSlider xiaBaSixSlisder;
    private GSlider xiaBaSvenSlisder;
    //嘴
    private GSlider mouthBigSlisder;
    private GSlider mouthSlisder;
    //耳朵
    private GSlider earsBigSlisder;
    private GSlider earsPosSlisder;
    private GSlider earsRotionlisder;
    //身高
    private GSlider heightSlisder;
    //上半身
    private GSlider shangShenOneSlisder;
    private GSlider shangShenTwoSlisder;
    private GSlider shangShenThreeSlisder;
    private GSlider shangShenFourSlisder;
    private GSlider shangShenFiveSlisder;
    private GSlider shangShenSixSlisder;
    //手臂
    private GSlider handsOneSlisder;
    private GSlider handsTwoSlisder;
    private GSlider handsThreeSlisder;
    private GSlider handsFourSlisder;
    private GSlider handsFiveSlisder;
    //腿部
    private GSlider footOneSlisder;
    private GSlider footTwoSlisder;
    private GSlider footThreeSlisder;
    private GSlider footFourSlisder;
    private GSlider footFiveSlisder;
    // 面部
    private GSlider faceOneSlisder;
    private GSlider faceTwoSlisder;
    private GSlider faceThreeSlisder;
    private GSlider faceFourSlisder;
    private GSlider faceFiveSlisder;
    private GSlider faceSixSlisder;
    #endregion
    // Use this for initialization
    void Start () {
        parent = new GameObject();
        parent.name = "heheh";
        //parent.AddComponent<SphereCollider>();
        //parent.AddComponent<ContorlCharaterRotion>();

        female = CharacterData.defData(EnumCharacterType.Charater_Female);
        male = CharacterData.defData(EnumCharacterType.Charater_Male);
        player = CharacterPlayerFactory.Creat(female);
        player.Creat();
        player.SetLocalEulerAngles(new Vector3(0, 160, 0));
        player.SetParent(parent.transform);

        //UISystem.Instance.player.PlayAnimation(ActionConst.HELLO);

        #region 主界面模块
        mianCom = gameObject.GetComponent<UIPanel>().ui;
        headBtn = mianCom.GetChild("n1").asButton;
        ShapeBtn = mianCom.GetChild("n3").asButton;
        hairBtn = mianCom.GetChild("n2").asButton;
        clothBtn = mianCom.GetChild("n0").asButton;
        closeBtn = mianCom.GetChild("n9").asButton;
        mainCont = mianCom.GetController("c1");

        headBtn.onClick.Add(OnHeadBtn);
        ShapeBtn.onClick.Add(OnShapeBtn);
        hairBtn.onClick.Add(OnHairBtn);
        clothBtn.onClick.Add(OnClothBtn);
        closeBtn.onClick.Add(OnCloseBtn);
        #endregion
        showCom = mianCom.GetChild("n6").asCom;
        manBtn = mianCom.GetChild("n10").asButton;
        grilBtn = mianCom.GetChild("n11").asButton;
        grilBtn.visible = false;
        ItemList = showCom.GetChild("n54").asList;
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("changePersonUI", "ItmeList"), typeof(CharaterItem));
        #region 详情界面List
        showCont = showCom.GetController("c1");
        slideCont = showCom.GetController("c2");

        headList = showCom.GetChild("n11").asList;
        headList.onClickItem.Add(OnHeadListItem);

        ShapeList = showCom.GetChild("n17").asList;
        ShapeList.onClickItem.Add(OnShapeListItem);

        hairList = showCom.GetChild("n18").asList;
        hairList.onClickItem.Add(OnHairListItem);

        clothList = showCom.GetChild("n19").asList;
        clothList.onClickItem.Add(OnClothListItem);
        #endregion
        #region 鼻子，眼睛滑动条
        //眼睛
        GComponent eyesBigCom = showCom.GetChild("n15").asCom;
        eyesBigSlisder = eyesBigCom.GetChild("n0").asSlider;
        eyesBigSlisder.onChanged.Add(OneyesBigSlisder);
        GComponent wocanCom = showCom.GetChild("n14").asCom;
        wocanSlisder = wocanCom.GetChild("n0").asSlider;
        wocanSlisder.onChanged.Add(OnwocanSlisderr);

        GComponent headBigCom = showCom.GetChild("n71").asCom;
        headBigSlisder = headBigCom.GetChild("n0").asSlider;
        headBigSlisder.onChanged.Add(OnheadBigSlisder);

        GComponent headCom = showCom.GetChild("n72").asCom;
        headSlisder = headCom.GetChild("n0").asSlider;
        headSlisder.onChanged.Add(OnheadSlisder);
        //鼻子
        GComponent noseJianCom = showCom.GetChild("n20").asCom;
        noseOneSlisder = noseJianCom.GetChild("n0").asSlider;
        noseOneSlisder.onChanged.Add(OnnoseJianSlisder);

        GComponent noseLiangCom = showCom.GetChild("n21").asCom;
        noseTwoSlisder = noseLiangCom.GetChild("n0").asSlider;
        noseTwoSlisder.onChanged.Add(OnnoseLiangSlisder);

        GComponent noseYiCom = showCom.GetChild("n22").asCom;
        noseThreeSlisder = noseYiCom.GetChild("n0").asSlider;
        noseThreeSlisder.onChanged.Add(OnnoseYiSlisder);

        GComponent noseFourCom = showCom.GetChild("n56").asCom;
        noseFourSlisder = noseFourCom.GetChild("n0").asSlider;
        noseFourSlisder.onChanged.Add(OnnoseFourSlisder);

        GComponent noseFiveCom = showCom.GetChild("n57").asCom;
        noseFiveSlisder = noseFiveCom.GetChild("n0").asSlider;
        noseFiveSlisder.onChanged.Add(OnnoseFiveSlisder);

        GComponent noseSixCom = showCom.GetChild("n58").asCom;
        noseSixSlisder = noseSixCom.GetChild("n0").asSlider;
        noseSixSlisder.onChanged.Add(OnnoseSixSlisder);

        GComponent noseSevenCom = showCom.GetChild("n59").asCom;
        noseSvenSlisder = noseSevenCom.GetChild("n0").asSlider;
        noseSvenSlisder.onChanged.Add(OnnoseSvenSlisder);
        //
        #endregion
        #region 下巴，颈部
        GComponent xiaBaOneCom = showCom.GetChild("n25").asCom;
        xiaBaOneSlisder = xiaBaOneCom.GetChild("n0").asSlider;
        xiaBaOneSlisder.onChanged.Add(OnxiaBaOneSlisder);

        GComponent xiaBaTwoCom = showCom.GetChild("n26").asCom;
        xiaBaTwoSlisder = xiaBaTwoCom.GetChild("n0").asSlider;
        xiaBaTwoSlisder.onChanged.Add(OnxiaBaTwoSlisder);

        GComponent xiaBaThreeCom = showCom.GetChild("n60").asCom;
        xiaBaThreeSlisder = xiaBaThreeCom.GetChild("n0").asSlider;
        xiaBaThreeSlisder.onChanged.Add(OnxiaBaThreeSlisder);

        GComponent xiaBaFourCom = showCom.GetChild("n61").asCom;
        xiaBaFourSlisder = xiaBaFourCom.GetChild("n0").asSlider;
        xiaBaFourSlisder.onChanged.Add(OnxiaBaFourSlisder);

        GComponent xiaBaFiveCom = showCom.GetChild("n62").asCom;
        xiaBaFiveSlisder = xiaBaFiveCom.GetChild("n0").asSlider;
        xiaBaFiveSlisder.onChanged.Add(OnxiaBaFiveSlisder);

        GComponent xiaBaSixCom = showCom.GetChild("n63").asCom;
        xiaBaSixSlisder = xiaBaSixCom.GetChild("n0").asSlider;
        xiaBaSixSlisder.onChanged.Add(OnxiaBaSixSlisder);

        GComponent xiaBaSevebCom = showCom.GetChild("n64").asCom;
        xiaBaSvenSlisder = xiaBaSevebCom.GetChild("n0").asSlider;
        xiaBaSvenSlisder.onChanged.Add(OnxiaBaSvenSlisder);
        #endregion
        #region 嘴 耳朵 身高 上身
        //嘴
        GComponent mouthBigCom = showCom.GetChild("n28").asCom;
        mouthBigSlisder = mouthBigCom.GetChild("n0").asSlider;
        mouthBigSlisder.onChanged.Add(OnmothBigSlisder);

        GComponent mouthCom = showCom.GetChild("n29").asCom;
        mouthSlisder = mouthCom.GetChild("n0").asSlider;
        mouthSlisder.onChanged.Add(OnmouthSlisder);
        //耳朵
        GComponent earsBigCom = showCom.GetChild("n31").asCom;
        earsBigSlisder = earsBigCom.GetChild("n0").asSlider;
        earsBigSlisder.onChanged.Add(OnearsBigSlisder);

        GComponent earsPosCom = showCom.GetChild("n32").asCom;
        earsPosSlisder = earsPosCom.GetChild("n0").asSlider;
        earsPosSlisder.onChanged.Add(OnearsPosSlisder);

        GComponent earsRotionCom = showCom.GetChild("n33").asCom;
        earsRotionlisder = earsRotionCom.GetChild("n0").asSlider;
        earsRotionlisder.onChanged.Add(OnearsRotionlisder);
        //身高
        GComponent heightCom = showCom.GetChild("n38").asCom;
        heightSlisder = heightCom.GetChild("n0").asSlider;
        heightSlisder.onChanged.Add(OnheightSlisder);
        //上半身
        GComponent shangShenOneCom = showCom.GetChild("n41").asCom;
        shangShenOneSlisder = shangShenOneCom.GetChild("n0").asSlider;
        shangShenOneSlisder.onChanged.Add(OnshangShenOneSlisder);

        GComponent shangShenTwoCom = showCom.GetChild("n42").asCom;
        shangShenTwoSlisder = shangShenTwoCom.GetChild("n0").asSlider;
        shangShenTwoSlisder.onChanged.Add(OnshangShenTwoSlisder);

        GComponent shangShenThreeCom = showCom.GetChild("n43").asCom;
        shangShenThreeSlisder = shangShenThreeCom.GetChild("n0").asSlider;
        shangShenThreeSlisder.onChanged.Add(OnshangShenThreeSlisder);

        GComponent shangShenFourCom = showCom.GetChild("n44").asCom;
        shangShenFourSlisder = shangShenFourCom.GetChild("n0").asSlider;
        shangShenFourSlisder.onChanged.Add(OnshangShenFourSlisder);

        GComponent shangShenFiveCom = showCom.GetChild("n65").asCom;
        shangShenFiveSlisder = shangShenFiveCom.GetChild("n0").asSlider;
        shangShenFiveSlisder.onChanged.Add(OnshangShenFiveSlisder);

        GComponent shangShenSixCom = showCom.GetChild("n66").asCom;
        shangShenSixSlisder = shangShenSixCom.GetChild("n0").asSlider;
        shangShenSixSlisder.onChanged.Add(OnshangShenSixSlisder);
        #endregion
        #region 手臂 腿部
        GComponent handsOneCom = showCom.GetChild("n46").asCom;
        handsOneSlisder = handsOneCom.GetChild("n0").asSlider;
        handsOneSlisder.onChanged.Add(OnhandsOneSlisder);
        GComponent handsTwoCom = showCom.GetChild("n47").asCom;
        handsTwoSlisder = handsTwoCom.GetChild("n0").asSlider;
        handsTwoSlisder.onChanged.Add(OnhandsTwoSlisder);
        GComponent handsThreeCom = showCom.GetChild("n67").asCom;
        handsThreeSlisder = handsThreeCom.GetChild("n0").asSlider;
        handsThreeSlisder.onChanged.Add(OnhandsThreeSlisder);
        GComponent handsFourCom = showCom.GetChild("n68").asCom;
        handsFourSlisder = handsFourCom.GetChild("n0").asSlider;
        handsFourSlisder.onChanged.Add(OnhandsFourSlisder);
        GComponent handsFiveCom = showCom.GetChild("n69").asCom;
        handsFiveSlisder = handsFiveCom.GetChild("n0").asSlider;
        handsFiveSlisder.onChanged.Add(OnhandsFiveSlisder);


        GComponent footOneCom = showCom.GetChild("n49").asCom;
        footOneSlisder = footOneCom.GetChild("n0").asSlider;
        footOneSlisder.onChanged.Add(OnfootOneSlisder);

        GComponent footTwoCom = showCom.GetChild("n50").asCom;
        footTwoSlisder = footTwoCom.GetChild("n0").asSlider;
        footTwoSlisder.onChanged.Add(OnfootTwoSlisder);

        GComponent footThreeCom = showCom.GetChild("n51").asCom;
        footThreeSlisder = footThreeCom.GetChild("n0").asSlider;
        footThreeSlisder.onChanged.Add(OnfootThreeSlisder);

        GComponent footFourCom = showCom.GetChild("n52").asCom;
        footFourSlisder = footFourCom.GetChild("n0").asSlider;
        footFourSlisder.onChanged.Add(OnfootFourSlisder);

        GComponent footFiveCom = showCom.GetChild("n70").asCom;
        footFiveSlisder = footFiveCom.GetChild("n0").asSlider;
        footFiveSlisder.onChanged.Add(OnfootFiveSlisder);
        #endregion
        #region 面部
        GComponent faceOneCom = showCom.GetChild("n35").asCom;
        faceOneSlisder = faceOneCom.GetChild("n0").asSlider;
        faceOneSlisder.onChanged.Add(OnfaceOneSlisder);

        GComponent faceTwoCom = showCom.GetChild("n36").asCom;
        faceTwoSlisder = faceTwoCom.GetChild("n0").asSlider;
        faceTwoSlisder.onChanged.Add(OnfaceTwoSlisder);

        GComponent faceThreeCom = showCom.GetChild("n73").asCom;
        faceThreeSlisder = faceThreeCom.GetChild("n0").asSlider;
        faceThreeSlisder.onChanged.Add(OnfaceThreeSlisder);

        GComponent faceFourCom = showCom.GetChild("n74").asCom;
        faceFourSlisder = faceFourCom.GetChild("n0").asSlider;
        faceFourSlisder.onChanged.Add(OnfaceFourSlisder);

        GComponent faceFiveCom = showCom.GetChild("n75").asCom;
        faceFiveSlisder = faceFiveCom.GetChild("n0").asSlider;
        faceFiveSlisder.onChanged.Add(OnfaceFiveSlisder);

        GComponent faceSixCom = showCom.GetChild("n76").asCom;
        faceSixSlisder = faceSixCom.GetChild("n0").asSlider;
        faceSixSlisder.onChanged.Add(OnfaceSixSlisder);
        #endregion
        manBtn.onClick.Add(OnManBtn);
        grilBtn.onClick.Add(OnGrilBtn);

        clouthItm = ClothModel.GetData();
        ItemList.onClickItem.Add(OnItmeList);
        #region animation
        animationList = mianCom.GetChild("n23").asList;
        animationList.onClickItem.Add(animationOnclick);
        #endregion
    }

    // Update is called once per frame
    private void animationOnclick(EventContext context)
    {
        GButton intem = (GButton)context.data;
        Debug.Log(intem.text);
        animeterContor(intem.text);

    }
    void Update () {
	
	}
    private void OnManBtn()
    {
        manPlayer = CharacterPlayerFactory.Creat(male);
        manPlayer.Creat();
        manPlayer.SetLocalEulerAngles(new Vector3(0, 160, 0));
        player.Destroy();
        if (grilPlayer != null)
            grilPlayer.Destroy();
        manBtn.visible = false;
        grilBtn.visible = true;
        six = 0;
    }
    private void OnGrilBtn()
    {
        grilPlayer = CharacterPlayerFactory.Creat(female);
        grilPlayer.Creat();
        grilPlayer.SetLocalEulerAngles(new Vector3(0, 160, 0));
        player.Destroy();
        if (manPlayer != null)
            manPlayer.Destroy();
        grilBtn.visible = false;
        manBtn.visible = true;
        six = 2;
    }
    private void OnItmeList(EventContext context)
    {
        CharaterItem _item = (CharaterItem)context.data;
        if (six == 1)
            player.PutOn(_item._vo);
        else if (six == 0)
            manPlayer.PutOn(_item._vo);
        else if (six == 2)
            grilPlayer.PutOn(_item._vo);
    }
    #region 主页面按钮功能
    private void OnHeadBtn()
    {
        mainCont.selectedIndex = 1;
    }
    private void OnShapeBtn()
    {
        mainCont.selectedIndex = 1;
        showCont.selectedIndex = 1;
    }
    private void OnHairBtn()
    {
        mainCont.selectedIndex = 1;
        showCont.selectedIndex = 2;
    }
    private void OnClothBtn()
    {
        mainCont.selectedIndex = 1;
        showCont.selectedIndex = 3;
    }
    private void OnCloseBtn()
    {
        mainCont.selectedIndex = 0;
    }
    #endregion
    private void OnHeadListItem(EventContext context)
    {
        GButton item =(GButton)context.data;
        Debug.Log(item.id);
        if (item.id == "_n38")
            slideCont.selectedIndex = 0;
        else if(item.id == "_n42")
            slideCont.selectedIndex = 1;
        else if(item.id == "_n46")
            slideCont.selectedIndex = 2;
        else if(item.id == "_n50")
            slideCont.selectedIndex = 3;
        else if (item.id == "_n54")
            slideCont.selectedIndex = 4;
        else if (item.id == "_n58")
            slideCont.selectedIndex = 5;
    }
    private void OnShapeListItem(EventContext context)
    {
        GButton item = (GButton)context.data;
        Debug.Log(item.id);
        if (item.id == "_n63")
            slideCont.selectedIndex = 6;
        if (item.id == "_n67")
            slideCont.selectedIndex = 7;
        if (item.id == "_n71")
            slideCont.selectedIndex = 8;
        if (item.id == "_n75")
            slideCont.selectedIndex = 9;
    }
    private void OnHairListItem(EventContext context)
    {
        GButton item = (GButton)context.data;
        Debug.Log(item.id);
        if (item.id == "_n80")
        {
            slideCont.selectedIndex = 10;
            index = "02";
            ClothItemList(index);
        }
        if (item.id == "_n84")
            slideCont.selectedIndex = 10;
    }
    private void OnClothListItem(EventContext context)
    {
        GButton item = (GButton)context.data;
        Debug.Log(item.id);
        if (item.id == "_n89")
        {
            index = "04";
            ClothItemList(index);
            slideCont.selectedIndex = 10;
        }
        if (item.id == "_n93")
        {
            slideCont.selectedIndex = 10;
            index = "05";
            ClothItemList(index);
        }
        if (item.id == "_n97")
        {
            slideCont.selectedIndex = 10;
            index = "06";
            ClothItemList(index);
        }
    }
    #region 鼻子，眼睛
    private void OneyesBigSlisder(EventContext context)
    {
        eyesBigSlisder.max = 50;
        float a = (eyesBigSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.eyeSize, a);
        ChangePer(EnumUmaParamters.eyeSize,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnwocanSlisderr(EventContext context)
    {
        wocanSlisder.max = 50;
        float a = (wocanSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.eyeRotation, a);
        ChangePer(EnumUmaParamters.eyeRotation,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnheadBigSlisder()
    {
        headBigSlisder.max = 50;
        float a = (headBigSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.headSize, a);
        ChangePer(EnumUmaParamters.headSize,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnheadSlisder()
    {
        headSlisder.max = 50;
        float a = (headSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.headWidth, a);
        ChangePer(EnumUmaParamters.headWidth,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseJianSlisder(EventContext context)
    {
        noseOneSlisder.max = 50;
        float a = (noseOneSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.noseCurve, a);
        ChangePer(EnumUmaParamters.noseCurve,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseLiangSlisder(EventContext context)
    {
        noseTwoSlisder.max = 50;
        float a = (noseTwoSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.noseFlatten, a);
        ChangePer(EnumUmaParamters.noseFlatten,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseYiSlisder(EventContext context)
    {
        noseThreeSlisder.max = 50;
        float a = (noseThreeSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.noseInclination, a);
        ChangePer(EnumUmaParamters.noseInclination,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseFourSlisder(EventContext context)
    {
        noseFourSlisder.max = 50;
        float a = (noseFourSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.nosePosition, a);
        ChangePer(EnumUmaParamters.nosePosition,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseFiveSlisder(EventContext context)
    {
        noseFiveSlisder.max = 50;
        float a = (noseFiveSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.nosePronounced, a);
        ChangePer(EnumUmaParamters.nosePronounced,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseSixSlisder(EventContext context)
    {
        noseSixSlisder.max = 50;
        float a = (noseSixSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        // player.SetDNA(EnumUmaParamters.noseSize, a);
        ChangePer(EnumUmaParamters.noseSize,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnnoseSvenSlisder(EventContext context)
    {
        noseSvenSlisder.max = 50;
        float a = (noseSvenSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.noseWidth, a);
        ChangePer(EnumUmaParamters.noseWidth,a);
        Debug.Log("++++++++++++++++" + a);
    }
    #endregion
    #region 下巴
    private void OnxiaBaOneSlisder()
    {
        xiaBaOneSlisder.max = 10;
        float a = (xiaBaOneSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.neckThickness, a);
        ChangePer(EnumUmaParamters.neckThickness,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnxiaBaTwoSlisder()
    {
        xiaBaTwoSlisder.max = 50;
        float a = (xiaBaTwoSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.chinSize, a);
        ChangePer(EnumUmaParamters.chinSize,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnxiaBaThreeSlisder()
    {
        xiaBaThreeSlisder.max = 50;
        float a = (xiaBaThreeSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.chinPronounced, a);
        ChangePer(EnumUmaParamters.chinPronounced,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnxiaBaFourSlisder()
    {
        xiaBaFourSlisder.max = 50;
        float a = (xiaBaFourSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.chinPosition, a);
        ChangePer(EnumUmaParamters.chinPosition,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnxiaBaFiveSlisder()
    {
        xiaBaFiveSlisder.max = 50;
        float a = (xiaBaFiveSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.mandibleSize, a);
        ChangePer(EnumUmaParamters.mandibleSize,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnxiaBaSixSlisder()
    {
        xiaBaSixSlisder.max = 50;
        float a = (xiaBaSixSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.jawsSize, a);
        ChangePer(EnumUmaParamters.jawsSize,a);
        Debug.Log("++++++++++++++++" + a);
    }
    private void OnxiaBaSvenSlisder()
    {
        xiaBaSvenSlisder.max = 50;
        float a = (xiaBaSvenSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.jawsPosition, a);
        ChangePer(EnumUmaParamters.jawsPosition,a);
        Debug.Log("++++++++++++++++" + a);
    }
    #endregion
    #region 嘴 耳朵 身高 上半身
    private void OnmothBigSlisder(EventContext context)
    {
        mouthBigSlisder.max = 20;
        float a = (mouthBigSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.lipsSize, a);
        ChangePer(EnumUmaParamters.lipsSize,a);
    }
    private void OnmouthSlisder(EventContext context)
    {
        mouthSlisder.max = 30;
        float a = (mouthSlisder.value + 50) * 0.01F;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.mouthSize, a);
        ChangePer(EnumUmaParamters.mouthSize, a);
    }
    private void OnearsBigSlisder()
    {
        earsBigSlisder.max = 10;
        float a = (earsBigSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.earsSize, a);
        ChangePer(EnumUmaParamters.earsSize, a);
    }
    private void OnearsPosSlisder()
    {
        earsPosSlisder.max = 10;
        float a = (earsPosSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.earsPosition, a);
        ChangePer(EnumUmaParamters.earsPosition, a);
    }
    private void OnearsRotionlisder()
    {
        earsRotionlisder.max = 10;
        float a = (earsRotionlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.earsRotation, a);
        ChangePer(EnumUmaParamters.earsRotation, a);
    }
    private void OnheightSlisder()
    {
        heightSlisder.max = 10;
        float a = (heightSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.height, a);
        ChangePer(EnumUmaParamters.height, a);
    }
    private void OnshangShenOneSlisder()
    {
        shangShenOneSlisder.max = 5;
        float a = (shangShenOneSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.upperMuscle, a);
        ChangePer(EnumUmaParamters.upperMuscle, a);
    }
    private void OnshangShenTwoSlisder()
    {
        shangShenTwoSlisder.max = 50;
        float a = (shangShenTwoSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.upperWeight, a);
        ChangePer(EnumUmaParamters.upperWeight,a);
    }
    private void OnshangShenThreeSlisder()
    {
        shangShenThreeSlisder.max = 50;
        float a = (shangShenThreeSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.belly, a);
        ChangePer(EnumUmaParamters.belly, a);
    }
    private void OnshangShenFourSlisder()
    {
        shangShenFourSlisder.max = 20;
        float a = (shangShenFourSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        player.SetDNA(EnumUmaParamters.waist, a);
        ChangePer(EnumUmaParamters.waist, a);
    }
    private void OnshangShenFiveSlisder()
    {
        shangShenFiveSlisder.max = 50;
        float a = (shangShenFiveSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.gluteusSize, a);
        ChangePer(EnumUmaParamters.gluteusSize, a);
    }
    private void OnshangShenSixSlisder()
    {
        shangShenSixSlisder.max = 50;
        float a = (shangShenSixSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.breastSize, a);
        ChangePer(EnumUmaParamters.breastSize, a);
    }
    #endregion
    #region 手臂 腿部
    private void OnhandsOneSlisder()
    {
        handsOneSlisder.max = 50;
        float a = (handsOneSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.armLength, a);
        ChangePer(EnumUmaParamters.armLength, a);
    }
    private void OnhandsTwoSlisder()
    {
        handsTwoSlisder.max = 50;
        float a = (handsTwoSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.forearmLength, a);
        ChangePer(EnumUmaParamters.forearmLength, a);
    }
    private void OnhandsThreeSlisder()
    {
        handsThreeSlisder.max = 20;
        float a = (handsThreeSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.armWidth, a);
        ChangePer(EnumUmaParamters.armWidth, a);
    }
    private void OnhandsFourSlisder()
    {
        handsFourSlisder.max = 20;
        float a = (handsFourSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.forearmWidth, a);
        ChangePer(EnumUmaParamters.forearmWidth, a);
    }
    private void OnhandsFiveSlisder()
    {
        handsFiveSlisder.max = 50;
        float a = (handsFiveSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.handsSize, a);
        ChangePer(EnumUmaParamters.handsSize, a);
    }
    private void OnfootOneSlisder()
    {
        footOneSlisder.max = 15;
        float a = (footOneSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.feetSize, a);
        ChangePer(EnumUmaParamters.feetSize, a);
    }
    private void OnfootTwoSlisder()
    {
        footTwoSlisder.max = 50;
        float a = (footTwoSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.legSeparation, a);
        ChangePer(EnumUmaParamters.legSeparation, a);
    }
    private void OnfootThreeSlisder()
    {
        footThreeSlisder.max = 10;
        float a = (footThreeSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.lowerMuscle, a);
        ChangePer(EnumUmaParamters.lowerMuscle, a);
    }
    private void OnfootFourSlisder()
    {
        footFourSlisder.max = 5;
        float a = (footFourSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.lowerWeight, a);
        ChangePer(EnumUmaParamters.lowerWeight, a);
    }
    private void OnfootFiveSlisder()
    {
        footFiveSlisder.max = 50;
        float a = (footFiveSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.legsSize, a);
        ChangePer(EnumUmaParamters.legsSize, a);
    }
    #endregion
    #region 面部
    private void OnfaceOneSlisder()
    {
        faceOneSlisder.max = 50;
        float a = (faceOneSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.cheekSize, a);
        ChangePer(EnumUmaParamters.cheekSize,a);
    }
    private void OnfaceTwoSlisder()
    {
        faceTwoSlisder.max = 50;
        float a = (faceTwoSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.cheekPosition, a);
        ChangePer(EnumUmaParamters.cheekPosition, a);
    }
    private void OnfaceThreeSlisder()
    {
        faceThreeSlisder.max = 50;
        float a = (faceThreeSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.lowCheekPronounced, a);
        ChangePer(EnumUmaParamters.lowCheekPronounced, a);
    }
    private void OnfaceFourSlisder()
    {
        faceFourSlisder.max = 50;
        float a = (faceFourSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.lowCheekPosition, a);
        ChangePer(EnumUmaParamters.lowCheekPosition, a);
    }
    private void OnfaceFiveSlisder()
    {
        faceFiveSlisder.max = 10;
        float a = (faceFiveSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.foreheadSize, a);
        ChangePer(EnumUmaParamters.foreheadSize, a);
    }
    private void OnfaceSixSlisder()
    {
        faceSixSlisder.max = 30;
        float a = (faceSixSlisder.value + 50) * 0.01f;
        Debug.Log("______________" + a);
        //player.SetDNA(EnumUmaParamters.foreheadPosition, a);
        ChangePer(EnumUmaParamters.foreheadPosition, a);
    }
    #endregion
    private void ClothItemList(string iconIndex)
    {
        ItemList.RemoveChildrenToPool();
        for (int a = 0; a < clouthItm.Count; a++)
        {
            ClothModel Icon = clouthItm[a];
            if (six == 1 || six == 2 && Icon.sex == "02")
            {
                if (iconIndex == "02")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
                else if (iconIndex == "04")
                {
                    if (iconIndex == Icon.wearpos || Icon.wearpos == "30")
                    {
                        CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                        _item.setVo(Icon);
                    }
                }
                else if (iconIndex == "05")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
                else if (iconIndex == "06")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
            }
            else if (six == 0 && Icon.sex == "01")
            {
                if (iconIndex == "02")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
                else if (iconIndex == "04")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
                else if (iconIndex == "05")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
                else if (iconIndex == "06")
                {
                    if (iconIndex != Icon.wearpos) continue;
                    CharaterItem _item = (CharaterItem)ItemList.AddItemFromPool();
                    _item.setVo(Icon);
                }
            }
        }
    }
    private void ChangePer(EnumUmaParamters type, float b)
    {
        if (six == 1)
            player.SetDNA(type, b);
        else if (six == 2)
            grilPlayer.SetDNA(type, b);
        else if (six == 0)
            manPlayer.SetDNA(type, b);
    }
    private void animeterContor(string action)
    {
        if (six == 1)
            player.PlayAnimation(action);
        else if (six == 2)
            grilPlayer.PlayAnimation(action);
        else if (six == 0)
            manPlayer.PlayAnimation(action);
    }
}
