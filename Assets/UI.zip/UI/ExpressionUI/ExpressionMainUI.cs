﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;
using System.Collections.Generic;
public class ExpressionMainUI : MonoBehaviour {
    private GComponent mianCom;
    private GButton sexBtn;
    private IExpressModel player;
    private GList experseList;
    private List<IExpressClip> exClipList = new List<IExpressClip>();
    private Camera camera = new Camera();
    private GButton playBtn;
    private IExpressClip playClip;
    private GButton backBtn;
    // Use this for initialization
    void Start () {
        camera = Camera.main;
        player = new ExpressModel_Female();
        player.Creat();
        player.SetParent(camera.transform);
        player.SetEulerAngles(new Vector3(0, 180f, 0));
        player.SetPosition(new Vector3(0.12f, -1.51f, 2.017f));
        mianCom = this.GetComponent<UIPanel>().ui;
        sexBtn = mianCom.GetChild("n5").asButton;
        sexBtn.onClick.Add(OnSexBtn);
        experseList = mianCom.GetChild("n2").asList;
        exClipList = player.clips;
        if (exClipList != null)
            showClip();
        playBtn = mianCom.GetChild("n7").asButton;
        playBtn.onClick.Add(OnPlayBtn);
        backBtn = mianCom.GetChild("n4").asButton;
        backBtn.onClick.Add(OnBackBtn);
    }
	
	// Update is called once per frame
	void Update () {
	
	}
    private void OnBackBtn()
    {
        IScence sceenOne = new ScenceEditor();
        sceenOne.Load();
    }
    private void OnPlayBtn()
    {
        if (playBtn.selected)
            player.Play(playClip);
        else
            player.Stop();
    }
    private void OnSexBtn()
    {
        if (sexBtn.selected)
        {
            if (player != null)
                player.Destroy();
            player = new ExpressModel_Male();
            player.Creat();
            player.SetParent(camera.transform);
            player.SetEulerAngles(new Vector3(0, 180f, 0));
            player.SetPosition(new Vector3(0.12f, -1.69f, 2.017f));
        }
        else
        {
            if(player != null)
                player.Destroy();
            player = new ExpressModel_Female();
            player.Creat();
            player.SetParent(camera.transform);
            player.SetEulerAngles(new Vector3(0, 180f, 0));
            player.SetPosition(new Vector3(0.12f, -1.51f, 2.017f));
        }
    }
    private Dictionary<string, IExpressClip> clipDic = new Dictionary<string, IExpressClip>();
    private void showClip()
    {
        experseList.RemoveChildren();
        if (clipDic != null)
            clipDic.Clear();
        for (int a = 0; a < exClipList.Count; a++)
        {
            IExpressClip clip = exClipList[a];
            GComponent itemCom = experseList.AddItemFromPool().asCom;
            Controller contell = itemCom.GetController("c1");
            GButton itemBtn = itemCom.GetChild("n4").asButton;
            itemBtn.title = clip.name;
            if (!clipDic.ContainsKey(itemBtn.title))
                clipDic.Add(itemBtn.title, clip);
            itemBtn.onClick.Add(OnItemBtn);
            if (clip.clip == null)
            {
                contell.selectedIndex = 1;
                itemBtn.enabled = false;
                GButton newBtn = itemCom.GetChild("n2").asCom.GetChild("n0").asButton;
                newBtn.onClick.Add(() => { clip.CreateClip(); showClip(); });
                GButton twoImportBtn = itemCom.GetChild("n2").asCom.GetChild("n1").asButton;
                twoImportBtn.onClick.Add(() => { clip.Export(); showClip(); });
            }
            else
            {
                contell.selectedIndex = 0;
                itemBtn.enabled = true;
                GButton EditBtn = itemCom.GetChild("n1").asCom.GetChild("n0").asButton;
                EditBtn.onClick.Add(() => { clip.Edit();});
                GButton DeletetBtn = itemCom.GetChild("n1").asCom.GetChild("n1").asButton;
                DeletetBtn.onClick.Add(() => { clip.Delete(); showClip(); });
                GButton importBtn = itemCom.GetChild("n1").asCom.GetChild("n2").asButton;
                importBtn.onClick.Add(() => { clip.Export(); showClip(); });
            }

        }
    }
    private void OnItemBtn(EventContext context)
    {
        GButton item = context.sender as GButton;
        Debug.Log(item.title);
        if (clipDic.ContainsKey(item.title))
            playClip = clipDic[item.title];
    }
}
#endif
