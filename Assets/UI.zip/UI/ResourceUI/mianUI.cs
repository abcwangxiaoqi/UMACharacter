﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;
using System.Collections.Generic;

public class mianUI : MonoBehaviour {
    private GComponent mianCom;
    private GList typeList;
    private GButton sexBtn;
    private List<ClothToBaseItem> baseItemList = new List<ClothToBaseItem>();
    private bool sexBool = true;//nv
    private Dictionary<string, string> wearNameType = new Dictionary<string, string>();
    private GList iconList;
    private List<string> vue = new List<string>();
    private ClothToBaseConfig config;
    private GButton saveBtn;
    private GButton backBtn;
    // Use this for initialization
    void Start () {
        mianCom = this.GetComponent<UIPanel>().ui;
        config = new ClothToBaseConfig();
        baseItemList = config.Load();

        typeList = mianCom.GetChild("n9").asList;
        typeList.onClickItem.Add(OnTypeList);
        sexBtn = mianCom.GetChild("n7").asButton;
        sexBtn.onClick.Add(OnSexBtn);
        iconList = mianCom.GetChild("n10").asList;
        wearNameType = new GetXmlData().wearDic;
        if (wearNameType != null)
            UpDataList();
        vue.Add(EnumClothToBase.ignore.ToString());
        vue.Add(EnumClothToBase.hide.ToString());
        vue.Add(EnumClothToBase.show.ToString());
        saveBtn = mianCom.GetChild("n11").asButton;
        saveBtn.onClick.Add(OnSaveBtn);
        backBtn = mianCom.GetChild("n12").asButton;
        backBtn.onClick.Add(OnBackBtn);
    }
	
	// Update is called once per frame
	void Update () {
	}
    private void OnBackBtn()
    {
        IScence sceenOne = new ScenceEditor();
        sceenOne.Load();
    }
    private void OnSaveBtn()
    {
        for (int a = 0; a < baseItemList.Count; a++)
        {
            string name = baseItemList[a].name;
            if (clothModleComDic.ContainsKey(name))
            {
                baseItemList[a] = clothModleComDic[name];
            }
        }
        config.Save(baseItemList);
        Debug.Log("保存好了");
    }
    private void OnSexBtn()
    {
        if (sexBtn.selected)
        {
            sexBool = false;
        }
        else
        {
            sexBool = true;
        }
    }
    private void UpDataList()
    {
        typeList.RemoveChildrenToPool();
        foreach (string wearType in wearNameType.Keys)
        {
            GButton typeBtnItem = typeList.AddItemFromPool().asButton;
            typeBtnItem.title = wearType;
        }
    }
    private Dictionary<string, ClothToBaseItem> clothModleComDic = new Dictionary<string, ClothToBaseItem>();
    private void OnTypeList(EventContext context)
    {
        iconList.RemoveChildren();
        GButton itemBtn = (GButton)context.data;
        if (wearNameType.ContainsKey(itemBtn.title))
        {
            if (sexBool)
            {
                for (int a = 0; a < baseItemList.Count; a++)
                {
                    ClothToBaseItem mod = new ClothToBaseItem();
                    mod = baseItemList[a];
                    if (mod.name.Substring(0, 2) == "02" && mod.name.Substring(2, 2) == wearNameType[itemBtn.title])
                    {
                        GComponent iconCom = iconList.AddItemFromPool().asCom;
                        GLabel iconLabel = iconCom.GetChild("n0").asLabel;
                        iconLabel.title = mod.name;
                        if (!clothModleComDic.ContainsKey(iconLabel.title))
                        {
                            clothModleComDic.Add(iconLabel.title, mod);
                        }
                        GLoader iconPoto = iconLabel.GetChild("icon").asLoader;
                        if (mod.LoadTexture() != null)
                            iconPoto.texture = new NTexture(mod.LoadTexture());
                        int number = iconCom.numChildren;
                        for (int i = 0; i< number;i ++)
                        {
                            GObject obj = iconCom.GetChildAt(i);
                            if (obj.group != null && obj.group.name == "n12")
                            {
                                GList chooseList = obj.asLabel.GetChild("n1").asComboBox.dropdown.GetChild("list").asList;
                                GComboBox chooseBox = obj.asLabel.GetChild("n1").asComboBox;
                                chooseBox.items = vue.ToArray();
                                if (obj.asLabel.title == "ArmUp")
                                    chooseBox.text = mod.ArmUp.ToString();
                                else if (obj.asLabel.title == "ArmMiddle")
                                    chooseBox.text = mod.ArmMiddle.ToString();
                                else if(obj.asLabel.title == "ArmDown")
                                    chooseBox.text = mod.ArmDown.ToString();
                                else if (obj.asLabel.title == "UpbodyMiddle")
                                    chooseBox.text = mod.UpbodyMiddle.ToString();
                                else if (obj.asLabel.title == "UpbodyDown")
                                    chooseBox.text = mod.UpbodyDown.ToString();
                                else if (obj.asLabel.title == "LowbodyUp")
                                    chooseBox.text = mod.LowbodyUp.ToString();
                                else if (obj.asLabel.title == "LowbodyMiddle")
                                    chooseBox.text = mod.LowbodyMiddle.ToString();
                                else if (obj.asLabel.title == "LowbodyDown")
                                    chooseBox.text = mod.LowbodyDown.ToString();
                                chooseBox.onChanged.Add(OnChooseBox);
                            }
                        }
                    }
                }
            }
            else
            {
                for (int a = 0; a < baseItemList.Count; a++)
                {
                    ClothToBaseItem mod = new ClothToBaseItem();
                    mod = baseItemList[a];
                    if (mod.name.Substring(0, 2) == "01" && mod.name.Substring(2, 2) == wearNameType[itemBtn.title])
                    {
                        GComponent iconCom = iconList.AddItemFromPool().asCom;
                        GLabel iconLabel = iconCom.GetChild("n0").asLabel;
                        iconLabel.title = mod.name;
                        if (!clothModleComDic.ContainsKey(iconLabel.title))
                        {
                            clothModleComDic.Add(iconLabel.title, mod);
                        }
                        GLoader iconPoto = iconLabel.GetChild("icon").asLoader;
                        if (mod.LoadTexture() != null)
                            iconPoto.texture = new NTexture(mod.LoadTexture());
                        int number = iconCom.numChildren;
                        for (int i = 0; i < number; i++)
                        {
                            GObject obj = iconCom.GetChildAt(i);
                            if (obj.group != null && obj.group.name == "n12")
                            {
                                GList chooseList = obj.asLabel.GetChild("n1").asComboBox.dropdown.GetChild("list").asList;
                                GComboBox chooseBox = obj.asLabel.GetChild("n1").asComboBox;
                                chooseBox.items = vue.ToArray();
                                if (obj.asLabel.title == "ArmUp")
                                    chooseBox.text = mod.ArmUp.ToString();
                                else if (obj.asLabel.title == "ArmMiddle")
                                    chooseBox.text = mod.ArmMiddle.ToString();
                                else if (obj.asLabel.title == "ArmDown")
                                    chooseBox.text = mod.ArmDown.ToString();
                                else if (obj.asLabel.title == "UpbodyMiddle")
                                    chooseBox.text = mod.UpbodyMiddle.ToString();
                                else if (obj.asLabel.title == "UpbodyDown")
                                    chooseBox.text = mod.UpbodyDown.ToString();
                                else if (obj.asLabel.title == "LowbodyUp")
                                    chooseBox.text = mod.LowbodyUp.ToString();
                                else if (obj.asLabel.title == "LowbodyMiddle")
                                    chooseBox.text = mod.LowbodyMiddle.ToString();
                                else if (obj.asLabel.title == "LowbodyDown")
                                    chooseBox.text = mod.LowbodyDown.ToString();
                                chooseBox.onChanged.Add(OnChooseBox);
                            }
                        }
                    }
                }
            }
        }
    }
    private void OnChooseBox(EventContext context)
    {
        GComboBox box = context.sender as GComboBox;
        Debug.Log(box.text);
        Debug.Log(box.parent.asLabel.title);
        GLabel iconLabel = box.parent.asLabel.parent.asCom.GetChild("n0").asLabel;
        if (clothModleComDic.ContainsKey(iconLabel.title))
        {
            EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            ClothToBaseItem itemMod = clothModleComDic[iconLabel.title];
            if (box.parent.asLabel.title == "ArmUp")
                itemMod.ArmUp = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "ArmMiddle")
                itemMod.ArmMiddle = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "ArmDown")
                itemMod.ArmDown = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "UpbodyMiddle")
                itemMod.UpbodyMiddle = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "UpbodyDown")
                itemMod.UpbodyDown = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "LowbodyUp")
                itemMod.LowbodyUp = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "LowbodyMiddle")
                itemMod.LowbodyMiddle = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            else if (box.parent.asLabel.title == "LowbodyDown")
                itemMod.LowbodyDown = (EnumClothToBase)EnumClothToBase.Parse(typeof(EnumClothToBase), box.text);
            clothModleComDic[iconLabel.title] = itemMod;
        }
    }
}
#endif
