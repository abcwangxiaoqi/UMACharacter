﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
public class CharacterBasisMainUI : MonoBehaviour
{
    #region
    private GComponent mainCom;
    private GComponent containCom;
    private GButton moudDataBtn;
    private Controller mainController;
    private GButton backBtn;
    private Dictionary<string, string> itemList = new Dictionary<string, string>();
    private GList wearTypeList;
    private GList moudleList;
    private GList manList;
    private GButton sexBtn;
    private GButton imporManBtn;
    private GButton imporWomanBtn;
    private GButton imporIcon;
    private GButton creatBtn;
    private GButton packBtn;
    private GButton impoeAsstBtn;
    private GButton plugBtn;
    private GButton androidBtn;
    private GButton clearBtn;
    private GButton httpBtn;
    private Controller sexCont;
    private ITemplate female;
    private GButton dressBtn;
    private GButton iconBtn;
    private bool sexBool = false;
    private GGraph gp;
    private Dictionary<string, TemplateClothItem> wearDic = new Dictionary<string, TemplateClothItem>();
    private GButton exseeBtn;
    private GButton resourcesBtn;
    #endregion
    // Use this for initialization
    void Start()
    {
        mainCom = this.GetComponent<UIPanel>().ui;
        containCom = mainCom.GetChild("n21").asCom;
        moudDataBtn = mainCom.GetChild("n5").asButton;
        backBtn = mainCom.GetChild("n20").asButton;
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("CharacterBasisUI", "item"), typeof(WearBtnItemCom));
        backBtn.visible = false;
        backBtn.onClick.Add(OnBackBtn);
        mainController = mainCom.GetController("c1");
        moudDataBtn.onClick.Add(OnMoudDataBtn);
        itemList = GetData.instant.setWearDic();

        imporManBtn = mainCom.GetChild("n0").asButton;
        imporManBtn.onClick.Add(OnImporManBtn);
        imporWomanBtn = mainCom.GetChild("n1").asButton;
        imporWomanBtn.onClick.Add(OnImporManBtn);
        imporIcon = mainCom.GetChild("n2").asButton;
        imporIcon.onClick.Add(OnImporIcon);
        creatBtn = mainCom.GetChild("n4").asButton;
        creatBtn.onClick.Add(OnCreatBtn);
        packBtn = mainCom.GetChild("n6").asButton;
        packBtn.onClick.Add(OnPackBtn);
        impoeAsstBtn = mainCom.GetChild("n7").asButton;
        impoeAsstBtn.onClick.Add(OnImpoeAsstBtn);
        plugBtn = mainCom.GetChild("n8").asButton;
        plugBtn.onClick.Add(OnPlugBtn);
        androidBtn = mainCom.GetChild("n9").asButton;
        androidBtn.onClick.Add(OnAndroidBtn);
        clearBtn = mainCom.GetChild("n10").asButton;
        clearBtn.onClick.Add(OnClearBtn);
        GComponent httpCom = mainCom.GetChild("n12").asCom;
        httpBtn = httpCom.GetChild("n0").asButton;
        httpBtn.onClick.Add(OnHttp);
        dressBtn = mainCom.GetChild("n17").asButton;
        dressBtn.onClick.Add(OnDressBtn);
        exseeBtn = mainCom.GetChild("n24").asButton;
        exseeBtn.onClick.Add(OnExessBtn);
        gp = mainCom.GetChild("n22").asGraph;
        resourcesBtn = mainCom.GetChild("n3").asButton;
        resourcesBtn.onClick.Add(OnRescourcesBtn);
    }
    // Update is called once per frame
    void Update()
    {

    }
    private void OnHttp()
    {
        if (httpBtn.selected)
        {
            Debug.LogError(11111111111111);
            CharacterConst.assetBundle = true;
        }
        else
        {
            Debug.LogError(2222222222222222);
            CharacterConst.assetBundle = false;
        }
    }
    private void OnRescourcesBtn()
    {
        IScence sceenOne = new ScenceResources();
        sceenOne.Load();
    }
    private void OnDressBtn()
    {
        IScence sceenOne = new ScenceFittingroom();
        sceenOne.Load();
    }
    private void OnExessBtn()
    {
        IScence sceenOne = new ScenceExpression();
        sceenOne.Load();
    }
    private void OnHttpBtn()
    {
        //CharacterConst.assetBundle = true;
        //CharacterConst.assetBundle = false;
    }
    private void OnClearBtn()
    {
        if (httpBtn.changeStateOnClick)

            ClearLocalData.clear();
    }
    private void OnAndroidBtn()
    {
        BuildPlayer build = new BuildPlayer_Android();
        build.Build();
    }
    private void OnPlugBtn()
    {
        ExportBase export = new CharacterCustomExport();
        export.ExportAsset();
    }
    private void OnImpoeAsstBtn()
    {
        CompressAssetbundleZip com = new CompressAssetbundleZip();
        com.Compress();
    }
    private void OnPackBtn()
    {
        PackagerEditor.Assetbundle_All();
    }
    private void OnCreatBtn()
    {
        IniEditor.iniData();
    }
    private void OnImporManBtn()
    {
        ImportBase female = new ImportFemale();
        female.Import();
    }
    private void OnImporIcon()
    {
        ImportBase import = new ImportIcon();
        import.Import();
    }
    private GLoader loader;
    private Controller winContor;
    private void OnMoudDataBtn()
    {
        GComponent winCom = UIPackage.CreateObject("CharacterBasisUI", "moduleData").asCom;
        mainController.selectedIndex = 1;
        backBtn.visible = true;
        winContor = winCom.GetController("c2");
        containCom.RemoveChildren();
        containCom.AddChild(winCom);
        wearTypeList = winCom.GetChild("n8").asList;
        if (itemList != null && wearTypeList != null)
            Wear();
        //wearTypeList.RemoveChildrenToPool();
        GButton manbtn = winCom.GetChild("n1").asButton;
        manbtn.onClick.Add(() => { sexBool = false; winContor.selectedIndex = 0;});
        GButton grilbtn = winCom.GetChild("n0").asButton;
        grilbtn.onClick.Add(() => { sexBool = true; winContor.selectedIndex = 0;});
        GButton onebtn = winCom.GetChild("n2").asButton;
        onebtn.onClick.Add(OnMoudleBtn);
        GButton twobtn = winCom.GetChild("n3").asButton;
        twobtn.onClick.Add(OnMoudleBtn);
        GButton threebtn = winCom.GetChild("n4").asButton;
        threebtn.onClick.Add(OnMoudleBtn);
        GButton fourbtn = winCom.GetChild("n5").asButton;
        fourbtn.onClick.Add(OnMoudleBtn);
        GButton fivebtn = winCom.GetChild("n6").asButton;
        fivebtn.onClick.Add(OnMoudleBtn);
        GButton iconBtn = winCom.GetChild("n7").asButton;
        iconBtn.onClick.Add(OnIconBtn);
        loader = iconBtn.GetChild("icon").asLoader;
        GButton creatBtn = winCom.GetChild("n9").asButton;
        creatBtn.onClick.Add(OnCreatTwoBtn);
        GButton saveBtn = winCom.GetChild("n16").asButton;
        saveBtn.onClick.Add(OnSaveBtn);
        gp.visible = false;
    }
    private void OnSaveBtn()
    {
        Debug.Log(clothsChoose.Count + "wuruifeng11");
        female.Save(icon, clothsChoose, null);
        Debug.Log("保存好了");
    }
    private ICharacterPlayer player;
    private void OnCreatTwoBtn()
    {
        CharacterData cd = new CharacterData();
        if (player != null)
            player.Destroy();
        if (sexBool)
        {
            cd.sex = 1;
            cd.avatars = modleList;
            cd.skin = SkinColor.transfer(Color.white);
            player = CharacterPlayerFactory.Creat(cd);
            player.Creat();
            player.SetLocalPosition(new Vector3(-15.9f, 0, 0));
            player.SetLocalEulerAngles(new Vector3(0, 180f, 0));
        }
        else
        {
            cd.sex = 0;
            cd.avatars = modleList;
            cd.skin = SkinColor.transfer(Color.white);
            player = CharacterPlayerFactory.Creat(cd);
            player.Creat();
            player.SetLocalPosition(new Vector3(-16f, -0.1f, 0.29f));
            player.SetLocalEulerAngles(new Vector3(0, 172.66f, 0));
        }
        Debug.Log("生成了没有");
    }
    private void On()
    {
        Debug.LogError(sexCont.selectedIndex);
    }
    private void OnBackBtn()
    {
        backBtn.visible = false;
        mainController.selectedIndex = 0;
        gp.visible = true;
        if (player != null)
            player.Destroy();
    }
    private Dictionary<string, GTextField> textName = new Dictionary<string, GTextField>();
    private void Wear()
    {
        wearTypeList.RemoveChildren();
        textName.Clear();
        foreach (string wearTypeName in itemList.Keys)
        {
            WearBtnItemCom item = (WearBtnItemCom)wearTypeList.AddItemFromPool();
            item.setVo(wearTypeName);
            GButton itemNt = item.GetChild("n0").asButton;
            GTextField txt = itemNt.GetChild("title").asTextField;
             textName.Add(itemList[wearTypeName], txt);
            itemNt.onClick.Add(OniniTemBtn);
        }
    }
    private void OnMoudleBtn(EventContext context)
    {
        GButton itemBtn = (GButton)context.sender;
        Debug.LogError(itemBtn.text);
        if (sexBool)
        {
            if (itemBtn.text == "1")
            {
                female = new Template_Female1();
                choseModle(female);
            }
            else if (itemBtn.text == "2")
            {
                female = new Template_Female2();
                choseModle(female);
            }
            else if (itemBtn.text == "3")
            {
                female = new Template_Female3();
                choseModle(female);
            }
            else if (itemBtn.text == "4")
            {
                female = new Template_Female4();
                choseModle(female);
            }
            else if (itemBtn.text == "5")
            {
                female = new Template_Female5();
                choseModle(female);
            }
        }
        else
        {
            if (itemBtn.text == "1")
            {
                female = new Template_Male1();
                choseModle(female);
            }
            else if (itemBtn.text == "2")
            {
                female = new Template_Male2();
                choseModle(female);
            }
            else if (itemBtn.text == "3")
            {
                female = new Template_Male3();
                choseModle(female);
            }
            else if (itemBtn.text == "4")
            {
                female = new Template_Male4();
                choseModle(female);
            }
            else if (itemBtn.text == "5")
            {
                female = new Template_Male5();
                choseModle(female);
            }
        }


    }
    private GTextField Field;
    private itemWindo windoItem;
    private List<TemplateClothItem> clothList = new List<TemplateClothItem>();
    private List<ClothModel> modleList = new List<ClothModel>();
    private void OniniTemBtn(EventContext context)
    {

        windoItem = new itemWindo();
        Debug.Log("wuruifeng");
        GButton itemBtn = (GButton)context.sender;
        Field = itemBtn.GetChild("title").asTextField;
        GTextField TextField = itemBtn.parent.GetChild("title").asTextField;
        Debug.LogError(TextField.text);
        if (TextField.text == EWearNames.topClouth)
            AddWearType("04");
        if (TextField.text == EWearNames.downClouth)
            AddWearType("05");
        if (TextField.text == EWearNames.Clouth)
            AddWearType("30");
        if (TextField.text == EWearNames.shoes)
            AddWearType("06");
        if (TextField.text == EWearNames.hair)
            AddWearType("02");
        if (TextField.text == EWearNames.glass)
            AddWearType("09");
        if (TextField.text == EWearNames.mouth)
            AddWearType("07");
        if (TextField.text == EWearNames.eye)
            AddWearType("08");
        if (TextField.text == EWearNames.jewelry)
            AddWearType("10");
        if (TextField.text == EWearNames.head)
            AddWearType("11");
        if (TextField.text == EWearNames.foot)
            AddWearType("12");
        if (TextField.text == EWearNames.Necklace)
            AddWearType("13");
        if (TextField.text == EWearNames.Earrings)
            AddWearType("14");
        if (TextField.text == EWearNames.hands)
            AddWearType("15");
        if (TextField.text == EWearNames.ring)
            AddWearType("16");
        if (TextField.text == EWearNames.Backpack)
            AddWearType("17");
        if (TextField.text == EWearNames.FlatBottomSock)
            AddWearType("18");
    }
    private List<TemplateClothItem> clothsChoose = new List<TemplateClothItem>();
    private void OnWearItem(EventContext context)
    {
        GLabel lable = (GLabel)context.data;
        Field.text = lable.text;
        if (wearDic.ContainsKey(Field.text))
        {
            clothsChoose.Add(wearDic[Field.text]);
            modleList.Add(wearDic[Field.text].cm);
        }
        Debug.LogError(clothsChoose.Count);
        windoItem.Hide();
    }
    //private TemplateIcon iconT;
    private List<TemplateClothItem> cloths;
    private void choseModle(ITemplate modle)
    {
        modleList.Clear();
        foreach (string tex in textName.Keys)
        {
            textName[tex].text = null;
        }
        icon = modle.LoadIcon();
        Texture2D icontext = icon.texture;
        if (icontext != null)
            loader.texture = new NTexture(icontext);
        else
        {
            loader.texture = null;
        }
        cloths = modle.LoadCloths();
        if (cloths.Count != 0)
        {
            for (int i = 0; i < cloths.Count; i++)
            {
                TemplateClothItem cItm = cloths[i];
                modleList.Add(cItm.cm);
                string wearText = cItm.name.Substring(2, 2);

                if (textName.ContainsKey(wearText))
                {
                    textName[wearText].text = cItm.name;
                }
            }
        }
        else
        {
            foreach (string tex in textName.Keys)
            {
                textName[tex].text = null;
            }
        }
    }
    private TemplateIcon icon;
    private void OnIconBtn(EventContext context)
    {
        GButton iconTemp = (GButton)context.sender;
        loader = iconTemp.GetChild("icon").asLoader;
        icon = female.ImportIcon();
        if (icon == null)
            return;
        loader.texture = new NTexture(icon.texture);
    }
    private void AddWearType(string number)
    {
        //modleList.Clear();
        TemplateCloth cloth = new TemplateCloth();
        if (sexBool)
            clothList = cloth.Load(EnumCharacterType.Charater_Female, number);
        else
            clothList = cloth.Load(EnumCharacterType.Charater_Male, number);
        for (int i = 0; i< clothsChoose.Count; i++)
        {
            string wearText = clothsChoose[i].name;
            Debug.Log(wearText.Substring(2,2));
            if (wearText.Substring(2, 2) == number)
            {
                clothsChoose.Remove(clothsChoose[i]);
            }
        }
        if (clothList.Count!= 0)
        {
            windoItem.Show();
            windoItem.wearNameList.RemoveChildren();
            for (int a = 0; a < clothList.Count; a++)
            {
                ClothModel comd = clothList[a].cm;
                modleList.Add(comd);
                windoItemCom item = (windoItemCom)windoItem.wearNameList.AddItemFromPool();
                //item.cloth = clothList[a];
                item.setData(clothList[a].name);
                if (!wearDic.ContainsKey(clothList[a].name))
                {
                    wearDic.Add(clothList[a].name, clothList[a]);
                }
            }
            windoItem.wearNameList.onClickItem.Add(OnWearItem);
        }
    }
}
#endif