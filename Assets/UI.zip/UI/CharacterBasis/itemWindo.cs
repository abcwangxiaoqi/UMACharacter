﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;

public class itemWindo : Window {
    public GList wearNameList;
    private GButton closeBtn;
    public itemWindo()
    {
    }

    protected override void OnInit()
    {
        //UIPackage.AddPackage("UI/characterBasisUI");
        this.contentPane = UIPackage.CreateObject("CharacterBasisUI", "windo").asCom;
        this.Center();
        this.modal = true;
        UIObjectFactory.SetPackageItemExtension(UIPackage.GetItemURL("CharacterBasisUI", "windoItem"), typeof(windoItemCom));
        closeBtn = contentPane.GetChild("n2").asButton;
        closeBtn.onClick.Add(OnCloseBtn);
    }
    private void OnCloseBtn()
    {
        this.Hide();
    }
    override protected void OnShown()
    {
        wearNameList = this.contentPane.GetChild("n0").asList;
    }
}
#endif
