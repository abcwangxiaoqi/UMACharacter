﻿#if UNITY_EDITOR
using UnityEngine;
using System.Collections;
using FairyGUI;

public class windoItemCom : GLabel {

    //private TemplateClothItem _cloth;

    //public TemplateClothItem cloth
    //{
    //    get { return _cloth; }
    //    set
    //    {
    //        _cloth = value;
    //        wearName.text = _cloth.name;
    //    }
    //}
    public GTextField wearName;
    public override void ConstructFromXML(FairyGUI.Utils.XML cxml)
    {
        base.ConstructFromXML(cxml);
        wearName = this.GetChild("title").asTextField;
    }
    public void setData(string name)
    {
        wearName.text = name;
    }
}
#endif
