﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using LitJson;
using System.IO;
using FairyGUI;
using System;

#if UNITY_EDITOR_OSX || UNITY_STANDALONE_OSX || UNITY_IOS || UNITY_ANDROID || true

public class FairyLoadIcon
{
    private Type m_type;
    private int m_HashCode = -1;
    private GLoader m_gloader;
    private string m_url;

    public void loadStart(string _url, Type type, GLoader _gloader)
    {
        m_gloader = _gloader;
        m_type = type;
        m_url = _url;
        //BaseWindow m_window = (BaseWindow)ModulesManager.instence.getModel(type);
        //if (m_window == null) return;
       // m_HashCode = m_window.GetHashCode();
        CoroutineProvide.Instance.StartCoroutine(startLoadMap(m_url));
    }

    IEnumerator startLoadMap(string _url)
    {
        if (!_url.StartsWith("http:") && !_url.StartsWith("file://"))
        {
            _url = "file://" + _url;
        }
        Debug.Log(_url);
        WWW www = new WWW(_url);
        yield return www;
        if (!System.String.IsNullOrEmpty(www.error))
        {
            Debug.Log("图片_加载错误！！！     " + _url);
        }
        else
        {
            //BaseWindow m_window = (BaseWindow)ModulesManager.instence.getModel(m_type);
            //if (m_window != null && m_HashCode == m_window.GetHashCode())
            //{
            //    m_gloader.texture = new NTexture(www.texture);
            //     PicManger.Instance.SaveData(_url, m_gloader.texture);
            //}
            m_gloader.texture = new NTexture(www.texture);
            PicManger.Instance.SaveData(_url, m_gloader.texture);
        }
    }
}
#endif