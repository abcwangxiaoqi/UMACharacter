﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.Events;

public class Timer
{
    private Action callback;
    private float timeDelay = 0f;
    private float m_delay;
    private float count = 0f;
    private bool lasting;
    private bool m_runing = false;
    private bool m_ignoreSleep = false;

    /// <summary>
    /// 忽略休眠状态
    /// 忽略休眠状态后将不再执行休眠时的调用，只会在回复激活后执行一次调用
    /// </summary>
    public bool ignoreSleep
    {
        get { return m_ignoreSleep; }
        set { m_ignoreSleep = value; }
    }

    /// <summary>
    /// 延迟时间，单位毫秒
    /// </summary>
    public uint delay
    {
        get { return (uint)(m_delay * 1000f); }
        set { m_delay = value / 1000f; }
    }

    public bool runing
    {
        get { return m_runing; }
        set { m_runing = value; }
    }

    public Timer(Action _callback, uint _delay = 1000, bool _lasting = true)
    {
        delay = _delay;
        lasting = _lasting;
        callback = _callback;
    }

    public void start()
    {
        if (runing) return;
        TimerService.Instance.addTimer(this);
        timeDelay = Time.realtimeSinceStartup;
        count = 0f;
    }

    public void stop()
    {
        TimerService.Instance.removeTimer(this);
        callback = null;
        runing = false;
    }
    
    public void cumulative()
    {
        count += Time.realtimeSinceStartup - timeDelay;
        timeDelay = Time.realtimeSinceStartup;
        if (count >= m_delay)
        {
            if (!lasting) stop();
            count -= m_delay;
            if (m_ignoreSleep) count = 0f;
            callback.Invoke();
        }
    }
}