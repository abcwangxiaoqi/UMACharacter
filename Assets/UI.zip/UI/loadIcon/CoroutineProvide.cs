﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class CoroutineProvide : MonoBehaviour
{
    private static CoroutineProvide m_instance;
    private static GameObject obj;
    public static CoroutineProvide Instance
    {
        get
        {
            if (m_instance == null)
            {
                obj = new GameObject("CoroutineProvide");
                m_instance = obj.AddComponent<CoroutineProvide>();
            }

            return m_instance;
        }
    }

    private void Update()
    {
        TimerService.Instance.updateTimer();
    }
}
