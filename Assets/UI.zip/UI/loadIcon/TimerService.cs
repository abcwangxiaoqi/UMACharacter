﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TimerService
{
    public static readonly TimerService Instance = new TimerService();
    private List<Timer> timers = new List<Timer>();
    private int index = -1;

    public TimerService()
    {

    }

    public void addTimer(Timer _timer)
    {
        if (timers.IndexOf(_timer) > -1) return;
        timers.Add(_timer);
    }

    public void removeTimer(Timer _timer)
    {
        int _index = timers.IndexOf(_timer);
        if (_index > -1) timers.RemoveAt(_index);
        index = _index;
    }

    public void updateTimer()
    {
        for (int i = 0, max = timers.Count; i < max; i++)
        {
            if (index > -1 && i > index)
            {
                i--;
                index = -1;
                max = timers.Count;
            }
            else if (index > -1 && i == index)
			{
				index = -1;
				continue;
			}

            timers[i].cumulative();
        }
    }
}
