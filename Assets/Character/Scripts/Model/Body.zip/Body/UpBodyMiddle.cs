﻿
using UMA;
public class UpBodyMiddle : Body
{
    public UpBodyMiddle(UMAContext _umaContext, ICharacterSlotOverly _characterSlotOverlay, IShareBody _share, SlotDataAsset _mine)
        : base(_umaContext, _characterSlotOverlay, _share, _mine)
    { }

    public override int SlotIndex
    {
        get { return int.Parse(WearPosConst.WEAR_POS_UPBODY_MIDDLE); }
    }
}