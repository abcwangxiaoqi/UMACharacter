﻿public interface IBody
{
    void Update(SlotOverlay so);
    void Update();
    void Show();
}
