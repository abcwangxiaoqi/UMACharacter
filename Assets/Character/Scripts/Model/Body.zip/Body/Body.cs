﻿
using UMA;
abstract public class Body : IBody
{
    UMAContext umaContext;
    ICharacterSlotOverly characterSlotOverlay;
    protected IShareBody share;
    public SlotDataAsset mine;
    public Body(UMAContext _umaContext, ICharacterSlotOverly _characterSlotOverlay, IShareBody _share, SlotDataAsset _mine)
    {
        umaContext = _umaContext;
        characterSlotOverlay = _characterSlotOverlay;
        share = _share;
        mine = _mine;

        umaContext.slotLibrary.AddSlotAsset(mine);

        Show();
    }

    abstract public int SlotIndex { get; }

    public void Update(SlotOverlay so)
    {
        EnumClothToBase state = GetState(so);
        if (state == EnumClothToBase.show)
        {
            Show();
        }
        else if (state == EnumClothToBase.hide)
        {
            Hide();
        }
    }

    bool showFlag = true;
    public void Show()
    {
        showFlag = true;
        characterSlotOverlay.AddSlotWithShareOverlays(SlotIndex, mine.slotName, share.SlotIndex);
    }


    void Hide()
    {
        showFlag = false;
        characterSlotOverlay.RemoveSlotWithIndex(SlotIndex);
    }


    public void Update()
    {
        if (!showFlag)
            return;

        characterSlotOverlay.AddSlotWithShareOverlays(SlotIndex, mine.slotName, share.SlotIndex);
    }
}