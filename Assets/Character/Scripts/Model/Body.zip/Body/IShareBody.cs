﻿using UnityEngine;
using System.Collections;
using UMA;

public interface IShareBody
{
    int SlotIndex{get;}
    SlotDataAsset Slot { get; }
    OverlayDataAsset Overlay { get; }
    void Update();
}
public class ShareBody : IShareBody
{
    UMAContext umaContext;
    SlotDataAsset slot;
    OverlayDataAsset overlay;
    CharacterData characterData;
    ICharacterSlotOverly characterSlotOverlay;
    public ShareBody(SlotDataAsset _slot,OverlayDataAsset _overlay,CharacterData _characterData,ICharacterSlotOverly _characterSlotOverlay)
    {
        umaContext = UMAContext.FindInstance();
        slot = _slot;
        overlay = _overlay;
        characterData = _characterData;
        characterSlotOverlay = _characterSlotOverlay;

        umaContext.slotLibrary.AddSlotAsset(slot);
        umaContext.overlayLibrary.AddOverlayAsset(overlay);

        Update();
    }
    public void Update()
    {
        characterSlotOverlay.AddSlotWithNameIndex(SlotIndex,slot.slotName);
        characterSlotOverlay.AddOverlayWithNameAndColor(SlotIndex, overlay.overlayName, characterData.skin.color());
    }

    public int SlotIndex
    {
        get 
        { 
            return  int.Parse(WearPosConst.WEAR_POS_UPBODY_UP);
        }
    }

    public SlotDataAsset Slot
    {
        get { return slot; }
    }


    public OverlayDataAsset Overlay
    {
        get { return overlay; }
    }
}