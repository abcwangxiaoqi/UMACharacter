#if UNITY_EDITOR
using UnityEngine;
public class UpbodyDownEditor : BaseClothItemEditor
{
    public UpbodyDownEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.CoatDown; }
    }
}
#endif