#if UNITY_EDITOR
using UnityEngine;
public class ArmUpEditor:BaseClothItemEditor
{
    public ArmUpEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.ArmUp; }
    }
}
#endif