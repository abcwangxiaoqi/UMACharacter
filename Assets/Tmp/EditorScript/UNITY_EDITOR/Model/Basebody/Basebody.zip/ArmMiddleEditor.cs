#if UNITY_EDITOR
using UnityEngine;
public class ArmMiddleEditor : BaseClothItemEditor
{
    public ArmMiddleEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.ArmMiddle; }
    }
}
#endif