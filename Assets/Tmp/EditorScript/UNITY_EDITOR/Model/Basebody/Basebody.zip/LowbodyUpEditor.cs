#if UNITY_EDITOR
using UnityEngine;
public class LowbodyUpEditor : BaseClothItemEditor
{
    public LowbodyUpEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.LowBodyUp; }
    }
}
#endif