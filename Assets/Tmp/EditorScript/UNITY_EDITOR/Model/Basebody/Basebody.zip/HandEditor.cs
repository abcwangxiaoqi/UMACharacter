#if UNITY_EDITOR
using UnityEngine;
public class HandEditor : BaseClothItemEditor
{
    public HandEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.Hands; }
    }
}
#endif