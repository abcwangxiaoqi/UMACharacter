#if UNITY_EDITOR
using UnityEngine;
public class FootEditor : BaseClothItemEditor
{
    public FootEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.Feet; }
    }
}
#endif