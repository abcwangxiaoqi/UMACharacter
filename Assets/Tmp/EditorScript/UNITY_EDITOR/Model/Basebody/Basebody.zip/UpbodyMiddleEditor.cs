#if UNITY_EDITOR
using UnityEngine;
public class UpbodyMiddleEditor : BaseClothItemEditor
{
    public UpbodyMiddleEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.CoatMiddle; }
    }
}
#endif