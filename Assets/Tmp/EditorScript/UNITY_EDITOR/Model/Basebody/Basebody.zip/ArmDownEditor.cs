#if UNITY_EDITOR
using UnityEngine;
public class ArmDownEditor : BaseClothItemEditor
{
    public ArmDownEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.ArmDown; }
    }
}
#endif