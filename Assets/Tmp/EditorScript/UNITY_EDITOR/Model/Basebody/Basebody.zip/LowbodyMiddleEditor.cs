#if UNITY_EDITOR
using UnityEngine;
public class LowbodyMiddleEditor : BaseClothItemEditor
{
    public LowbodyMiddleEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.LowBodyMiddle; }
    }
}
#endif