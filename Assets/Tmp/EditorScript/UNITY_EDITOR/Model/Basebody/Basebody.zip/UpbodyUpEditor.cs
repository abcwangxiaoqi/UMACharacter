#if UNITY_EDITOR
using UnityEngine;
public class UpbodyUpEditor : BaseClothItemEditor
{
    public UpbodyUpEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.CoatUp; }
    }
}
#endif