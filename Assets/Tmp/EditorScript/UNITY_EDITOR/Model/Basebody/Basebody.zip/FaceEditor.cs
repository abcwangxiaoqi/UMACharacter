#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UMA;
using UnityEditor;
using UnityEngine;
public class FaceEditor:BaseClothItemEditor
{
    public FaceEditor(IFbxItem go) : base(go) { }

    public override string PartName
    {
        get { return CharacterConst.Face; }
    }
}
#endif